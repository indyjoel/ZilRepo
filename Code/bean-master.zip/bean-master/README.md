# bean
A short game so I can play around with ZIL.

Built with zilf-0.8 :
https://bitbucket.org/jmcgrew/zilf/wiki/Home
