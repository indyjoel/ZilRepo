int main(int argc, char *argv[]) {
    double d;
    int i;
    if (!argc) d = 0;
    if (!argc) d = 0;
    i = d;
    if (!argc) return i;
}
