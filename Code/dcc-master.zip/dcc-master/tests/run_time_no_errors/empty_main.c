//dcc_flags=
//dcc_flags=-fsanitize=address
//dcc_flags=--leak-check

int main(void) {
}
