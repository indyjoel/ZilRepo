#include <stdio.h>

void read(void) {
    printf("hello world\n");
}

int main(void) {
    read();
}
