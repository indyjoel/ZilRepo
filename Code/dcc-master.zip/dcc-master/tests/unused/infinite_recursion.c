int main(int argc, char *argv[]) { if (argc) return 1 + main(argc, argv);}
