#include <stdio.h>

int main(int argc, char *argv[]) {
    FILE *f[2];
    f[0] = NULL;
    fgetc(f[argc]);
}
