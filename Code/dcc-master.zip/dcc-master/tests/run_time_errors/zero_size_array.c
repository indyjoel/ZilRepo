int main(void) {
    int a[0];
    return a[0];
}
