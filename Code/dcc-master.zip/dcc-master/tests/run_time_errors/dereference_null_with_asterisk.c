#include <stdio.h>
int main(void) {
    int *a = NULL;
    *a = 42;
}
