#include <iostream>

int main(int argc, char *argv[]) {
    int a[2];
    a[0] = 0;
    std::cout << "Hello, it is good to C you!\n";
    return a[argc];
}
