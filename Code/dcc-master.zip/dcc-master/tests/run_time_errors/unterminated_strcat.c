#include <string.h>

int main(void) {
    char c = 'd';
    char s[5];
    strcat(s, &c);
}
