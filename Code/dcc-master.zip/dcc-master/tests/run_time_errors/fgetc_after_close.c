#include <stdio.h>

int main(void) {
    fclose(stdin);
    fgetc(stdin);
}
