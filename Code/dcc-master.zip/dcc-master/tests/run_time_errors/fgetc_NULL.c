#include <stdio.h>

int main(void) {
    FILE *f = NULL;
    fgetc(f);
}
