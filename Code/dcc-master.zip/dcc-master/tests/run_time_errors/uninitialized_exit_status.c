// A simple C program that attempts to be punny
// Written 23/2/2017
// by Angela Finlayson (angf@cse.unsw.edu.au)
// for COMP1511 Lab 01 Exercise 1

#include <stdio.h>

int main(int argc, char *argv[]) {
    int a[2];
    a[0] = 0;
    printf("Hello, it is good to C you!\n");

    return a[argc];
}
