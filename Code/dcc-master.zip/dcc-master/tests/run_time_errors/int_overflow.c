#include <limits.h>

int main(int argc, char **argv) {
    int k = INT_MAX;
    k += argc;
}
