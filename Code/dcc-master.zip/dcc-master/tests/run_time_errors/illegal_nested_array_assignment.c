int main(int argc, char **argv) {
    int a[] = { 1, 2, 3, 4 };
    a[a[a[a[a[0]]]]] = 1;
}
