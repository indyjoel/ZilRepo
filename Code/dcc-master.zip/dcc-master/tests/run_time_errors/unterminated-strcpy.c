#include <string.h>

int main(void) {
    char i[2];
    char o[2];
    i[0] = 'H';
    strcpy(o, i);
}
