//dcc_flags=--leak-check

#include <stdlib.h>

int main(void) {
    malloc(1);
}
