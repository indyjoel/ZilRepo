int main(int argc, char *argv[]) {
    int a[2];
    a[argc] = 1;
    return a[0] + a[0];
}
