#include <stdio.h>
int main(void) {
    int *a = NULL;
    return a[0];
}
