#include <iostream>

int main(int argc, char **argv) {
    std::cout << 42 % (argc - 1) << "\n";
}
