#include <string.h>

int main(void) {
    char i[2];
    i[0] = 'H';
    return strlen(i);
}
