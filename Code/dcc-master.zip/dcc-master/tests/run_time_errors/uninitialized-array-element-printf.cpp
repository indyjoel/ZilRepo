#include <iostream>

int main(int argc, char **argv) {
    int a[1000];
    a[42] = 42;
    std::cout << a[argc] << "\n";
}
