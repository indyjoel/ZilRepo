int main(void) {
    int b;
    int a;
    if (a = b) {
    }

    a = c;
}
