int main(void) {
    int x = x + 1;
}
