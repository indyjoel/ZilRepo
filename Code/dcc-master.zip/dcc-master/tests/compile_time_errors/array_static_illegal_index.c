int main(void) {
    int a[5];
    a[5] = 0;
}
