int main(void) {
    int a[5];
    a["0"] = 0;
}
