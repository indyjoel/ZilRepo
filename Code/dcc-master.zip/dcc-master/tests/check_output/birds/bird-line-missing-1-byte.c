// A simple C program that prints an ASCII bird
// Written 1/3/2017
// by Angela Finlayson (angf@cse.unsw.edu.au)

#include <stdio.h>

int main(void) {
    printf("  ___\n");
    printf(" ('v')\n");
    printf("((___)\n");
    printf(" ^   ^\n");
    return 0;
}
