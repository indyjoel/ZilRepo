// A simple C program that prints an ASCII bird
// Written 1/3/2017
// by Angela Finlayson (angf@cse.unsw.edu.au)

#include <stdio.h>

int main(void) {
    for (int i = 0; i < 100000; i++) {
        printf("____________________________________________________________");
    }
    return 0;
}
