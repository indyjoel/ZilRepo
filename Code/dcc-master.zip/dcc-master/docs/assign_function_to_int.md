You will get this error if for example, you write code like this::

```c
int a;
a = square;
```

when you wanted to do this:

```c
int a;
a = square(5);
```
