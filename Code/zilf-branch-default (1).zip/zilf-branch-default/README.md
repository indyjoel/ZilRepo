# README #

### What is ZILF? ###

It's a set of tools for working with the ZIL interactive fiction language, including a compiler, assembler, disassembler, and game library.

### How do I get set up? ###

Someday we'll fill in this section with instructions for building the project, configuring it, installing dependencies, running tests, etc.

### Contribution guidelines ###

Someday we'll fill in this section with instructions for writing tests, getting your code reviewed, etc.

### Who do I talk to? ###

The primary contact is Tara McGrew (a.k.a. vaporware), who may be found on the [IntFic forum](https://www.intfic.com/), [IntFiction forum](http://intfiction.org/forum/), or [ifMUD](http://ifmud.port4000.com/).

To report a bug or request a feature, please use our JIRA server at [vaporware.atlassian.net](https://vaporware.atlassian.net/projects/ZILF).

### What else do I need to know? ###

This project's ongoing development is made possible by the hosting services generously provided by [Octobus](https://octobus.net/) and [Clever Cloud](https://www.clever-cloud.com/).
