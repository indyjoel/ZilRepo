﻿/* Copyright 2010-2023 Tara McGrew
 * 
 * This file is part of ZILF.
 * 
 * ZILF is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * ZILF is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with ZILF.  If not, see <http://www.gnu.org/licenses/>.
 */

#nullable enable

using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Zilf.Playground.Services.Templates
{
    public class ProjectTemplates
    {
        [JsonPropertyName("showcase")]
        public string[] Showcase { get; set; } = default!;

        [JsonPropertyName("templates")]
        public Dictionary<string, Template> Templates { get; set; } = default!;

        [JsonPropertyName("libraries")]
        public Dictionary<string, Library>? Libraries { get; set; }
    }

    public class Template
    {
        [JsonPropertyName("title")]
        public string Title { get; set; } = default!;

        [JsonPropertyName("description")]
        public string Description { get; set; } = default!;

        [JsonPropertyName("features")]
        public string[]? Features { get; set; }

        [JsonPropertyName("icon")]
        public string? Icon { get; set; }

        [JsonPropertyName("files")]
        public string[] Files { get; set; } = default!;

        [JsonPropertyName("include")]
        public string[]? Include { get; set; }
    }

    public class Library
    {
        [JsonPropertyName("files")]
        public string[] Files { get; set; } = default!;
    }
}
