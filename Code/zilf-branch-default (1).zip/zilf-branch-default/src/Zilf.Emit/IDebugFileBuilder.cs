﻿/* Copyright 2010-2023 Tara McGrew
 * 
 * This file is part of ZILF.
 * 
 * ZILF is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * ZILF is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with ZILF.  If not, see <http://www.gnu.org/licenses/>.
 */

namespace Zilf.Emit
{
    public interface IDebugFileBuilder
    {
        /// <summary>
        /// Marks an operand as an action constant.
        /// </summary>
        /// <param name="action">The operand whose value identifies an action.</param>
        /// <param name="name">The name of the action.</param>
        void MarkAction(IOperand action, string name);
        /// <summary>
        /// Marks the bounds of an object definition.
        /// </summary>
        /// <param name="obj">The object being defined.</param>
        /// <param name="start">The position where the object definition begins.</param>
        /// <param name="end">The position where the object definition ends.</param>
        void MarkObject(IObjectBuilder obj, DebugLineRef start, DebugLineRef end);
        /// <summary>
        /// Marks the bounds of a routine definition.
        /// </summary>
        /// <param name="routine">The routine being defined.</param>
        /// <param name="start">The position where the routine definition begins.</param>
        /// <param name="end">The position where the routine definition ends.</param>
        void MarkRoutine(IRoutineBuilder routine, DebugLineRef start, DebugLineRef end);
        /// <summary>
        /// Marks a sequence point at the current position in a routine.
        /// </summary>
        /// <param name="routine">The routine being defined.</param>
        /// <param name="point">The position corresponding to the next
        /// instruction emitted.</param>
        void MarkSequencePoint(IRoutineBuilder routine, DebugLineRef point);
    }
}