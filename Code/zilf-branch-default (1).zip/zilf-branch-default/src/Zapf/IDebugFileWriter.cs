﻿/* Copyright 2010-2023 Tara McGrew
 * 
 * This file is part of ZILF.
 * 
 * ZILF is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * ZILF is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with ZILF.  If not, see <http://www.gnu.org/licenses/>.
 */

using System.Collections.Generic;

namespace Zapf
{
    public interface IDebugFileWriter
    {
        void Close();

        void StartRoutine(LineRef start, int address, string name, IEnumerable<string> locals);
        bool InRoutine { get; }
        void RestartRoutine();
        void WriteLine(LineRef loc, int address);
        void EndRoutine(LineRef end, int address);

        void WriteAction(ushort number, string name);
        void WriteArray(ushort offsetFromGlobal, string name);
        void WriteAttr(ushort number, string name);
        void WriteClass(string name, LineRef start, LineRef end);
        void WriteFakeAction(ushort number, string name);
        void WriteFile(byte number, string includeName, string actualName);
        void WriteGlobal(byte number, string name);
        void WriteHeader(byte[] header);
        void WriteMap(IEnumerable<KeyValuePair<string, int>> map);
        void WriteObject(ushort number, string name, LineRef start, LineRef end);
        void WriteProp(ushort number, string name);
    }
}
