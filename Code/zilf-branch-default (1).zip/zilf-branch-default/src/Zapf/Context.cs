﻿/* Copyright 2010-2023 Tara McGrew
 * 
 * This file is part of ZILF.
 * 
 * ZILF is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * ZILF is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with ZILF.  If not, see <http://www.gnu.org/licenses/>.
 */

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;
using Zilf.Common.StringEncoding;
using Zapf.Parsing.Diagnostics;
using Zapf.Parsing.Instructions;
using Zilf.Common;

namespace Zapf
{
    public delegate IDebugFileWriter GetDebugWriterDelegate(Stream stream);

    public sealed class Context : IErrorSink, IDisposable
    {
        public bool Quiet, InformMode, ListAddresses, AbbreviateMode, XmlDebugMode;
        public string? InFile, OutFile, DebugFile;
        public string? Creator = "ZAPF";
        public string? Serial;
        public byte ZVersion, ZFlags;
        public ushort ZFlags2;
        public short? Release;

        public int FunctionsOffset, StringsOffset;

        public int ErrorCount, WarningCount;

        public Dictionary<string, KeyValuePair<ushort, ZOpAttribute>>? OpcodeDict;

        public StringEncoder StringEncoder;

        public readonly AbbrevFinder AbbrevFinder;

        public readonly Dictionary<string, Symbol> LocalSymbols;

        public readonly Dictionary<string, Symbol> GlobalSymbols;

        public readonly List<Fixup> Fixups;

        public IDebugFileWriter? DebugWriter;

        public readonly Dictionary<string, Symbol> DebugFileMap;

        /// <summary>
        /// If true, a reference to an undefined global symbol is an error,
        /// and expensive statistics may be collected.
        /// </summary>
        public bool FinalPass;

        /// <summary>
        /// If true, another measuring pass is needed because labels have moved.
        /// </summary>
        public bool MeasureAgain;

        public int? TableStart, TableSize;
        public bool InVocab;

        public IFileSystem FileSystem { get; set; } = PhysicalFileSystem.Instance;

        public GetDebugWriterDelegate? InterceptGetDebugWriter;

        char? LanguageEscapeChar { get; set; }

        IDictionary<char, char> LanguageSpecialChars { get; }

        Stream? stream;
        Stream? prevStream;
        int position;
        int globalVarCount, objectCount;

        readonly Stack<string> fileStack;

        int vocabStart, vocabRecSize, vocabKeySize;

        /// <summary>
        /// The node index where the reassembly scope started, or -1 if none.
        /// </summary>
        int reassemblyNodeIndex = -1;
        /// <summary>
        /// The story file position where the reassembly scope started, or -1 if none.
        /// </summary>
        int reassemblyPosition = -1;
        /// <summary>
        /// The position of the <see cref="AbbrevFinder"/> at the beginning of the
        /// reassembly scope.
        /// </summary>
        int reassemblyAbbrevPos;
        /// <summary>
        /// The symbol of the function that owns the reassembly scope.
        /// </summary>
        Symbol? reassemblySymbol;

        /// <summary>
        /// The local labels that have been encountered in the current reassembly scope
        /// before their definitions.
        /// </summary>
        /// <remarks>
        /// When one of these labels is defined, we rewind to the beginning of the
        /// reassembly scope and start again using the new value.
        /// </remarks>
        readonly Dictionary<string, bool> reassemblyLabels; // TODO: convert to HashSet

        /// <summary>
        /// The global labels that have been encountered in the current reassembly scope
        /// with unexpected values, mapped to delegates that check the expected value and
        /// handle mismatches.
        /// </summary>
        /// <remarks>
        /// These are checked at the end of the reassembly scope.
        /// </remarks>
        readonly Dictionary<Symbol, Action> deferredGlobalLabelChecks;

        public Context()
        {
            StringEncoder = new StringEncoder();
            AbbrevFinder = new AbbrevFinder();

            LocalSymbols = new Dictionary<string, Symbol>(25);
            GlobalSymbols = new Dictionary<string, Symbol>(200);
            Fixups = new List<Fixup>(200);
            DebugFileMap = new Dictionary<string, Symbol>();

            fileStack = new Stack<string>();
            reassemblyLabels = new Dictionary<string, bool>();
            deferredGlobalLabelChecks = new Dictionary<Symbol, Action>();

            ZVersion = Program.DEFAULT_ZVERSION;

            LanguageSpecialChars = new Dictionary<char, char>();
        }

        public void Restart()
        {
            ErrorCount = WarningCount = 0;

            LocalSymbols.Clear();
            GlobalSymbols.Clear();
            Fixups.Clear();
            DebugFileMap.Clear();

            fileStack.Clear();
            reassemblyLabels.Clear();

            string stackName = InformMode ? "sp" : "STACK";
            GlobalSymbols.Add(stackName, new Symbol(stackName, SymbolType.Variable, 0));

            LanguageEscapeChar = null;
            LanguageSpecialChars.Clear();
        }

        public void WriteByte(byte b)
        {
            position++;

            stream?.WriteByte(b);
        }

        /// <exception cref="SeriousError"><paramref name="sym"/> is undefined.</exception>
        public void WriteByte(Symbol sym)
        {
            switch (sym.Type)
            {
                case SymbolType.Unknown when FinalPass:
                    Errors.ThrowSerious("undefined symbol");
                    break;

                case SymbolType.Unknown:
                    WriteByte(0);
                    break;

                default:
                    WriteByte((byte)sym.Value);
                    break;
            }
        }

        public void WriteWord(ushort w)
        {
            position += 2;

            if (stream != null)
            {
                stream.WriteByte((byte)(w >> 8));
                stream.WriteByte((byte)w);
            }
        }

        /// <exception cref="SeriousError"><paramref name="sym"/> is undefined.</exception>
        public void WriteWord(Symbol sym)
        {
            switch (sym.Type)
            {
                case SymbolType.Unknown when FinalPass:
                    Errors.ThrowSerious("undefined symbol");
                    break;

                case SymbolType.Unknown:
                    WriteWord(0);
                    break;

                default:
                    WriteWord((ushort)sym.Value);
                    break;
            }
        }

        /// <exception cref="InvalidOperationException">The object file is closed.</exception>
        public byte ReadByte()
        {
            if (stream == null)
                throw new InvalidOperationException("Object file is closed");

            position++;

            return (byte)stream.ReadByte();
        }

        public void WriteZString(string str, bool withLength, StringEncoderMode mode = StringEncoderMode.Normal)
        {
            MaybeProcessEscapeChars(ref str);

            var zstr = StringEncoder.Encode(str, mode);
            if (FinalPass && AbbreviateMode && mode != StringEncoderMode.NoAbbreviations)
                AbbrevFinder.AddText(str);

            if (withLength)
                WriteByte((byte)(zstr.Length / 2));

            position += zstr.Length;
            stream?.Write(zstr, 0, zstr.Length);
        }

        void MaybeProcessEscapeChars(ref string str)
        {
            // ReSharper disable once ConditionIsAlwaysTrueOrFalse      // false alarm!
            if (LanguageEscapeChar is not char escape || str.IndexOf((char)LanguageEscapeChar) < 0)
                return;

            var sb = new StringBuilder(str);

            for (int i = 0; i < sb.Length - 1; i++)
            {
                if (sb[i] != escape)
                    continue;

                var next = sb[i + 1];
                if (next == escape)
                {
                    // %% => %
                    sb.Remove(i, 1);
                }
                else
                {
                    // translate according to LanguageSpecialChars
                    if (!LanguageSpecialChars.TryGetValue(next, out var translation))
                        continue;

                    sb.Remove(i, 1);
                    sb[i] = translation;
                }
            }

            str = sb.ToString();
        }

        public void WriteZStringLength(string str)
        {
            var zstr = StringEncoder.Encode(str);
            WriteByte((byte)(zstr.Length / 2));
        }

        public int ZWordChars => ZVersion >= 4 ? 9 : 6;

        public void WriteZWord(string str)
        {
            MaybeProcessEscapeChars(ref str);

            var zstr = StringEncoder.Encode(str, ZWordChars, StringEncoderMode.NoAbbreviations);
            position += zstr.Length;

            stream?.Write(zstr, 0, zstr.Length);
        }

        public bool AtVocabRecord => InVocab && (position - vocabStart) % vocabRecSize == 0;

        public void EnterVocab(int recSize, int keySize)
        {
            if (!InVocab)
            {
                prevStream = stream;
                stream = new MemoryStream();
            }

            InVocab = true;

            vocabStart = position;
            vocabRecSize = recSize;
            vocabKeySize = keySize;
        }

        public void LeaveVocab(ISourceLine src)
        {
            if (InVocab)
            {
                // restore stream
                if (!((MemoryStream)stream!).TryGetBuffer(out var bufferSegment))
                    throw new InvalidOperationException("Can't access vocab buffer");

                var buffer = bufferSegment.AsSpan();

                stream = prevStream;
                prevStream = null;
                InVocab = false;

                // sort vocab words
                // we use an insertion sort because ZILF's vocab table is mostly sorted already
                int records = buffer.Length / vocabRecSize;
                Span<byte> temp = stackalloc byte[vocabRecSize];

                var newIndexes = new int[records];
                newIndexes[0] = 0;

                for (int i = 1; i < records; i++)
                {
                    if (VocabCompare(buffer, i - 1, i) > 0)
                    {
                        VocabRecord(buffer, i).CopyTo(temp);

                        var home = VocabSearch(buffer, i - 1, i);
                        VocabMove(buffer, home, home + 1, i - home);

                        temp.CopyTo(VocabRecord(buffer, home));

                        for (int j = 0; j < i; j++)
                            if (newIndexes[j] >= home && newIndexes[j] < i)
                                newIndexes[j]++;

                        newIndexes[i] = home;
                    }
                    else
                    {
                        newIndexes[i] = i;
                    }
                }

                // update global labels that point to vocab words
                foreach (var sym in GlobalSymbols.Values)
                {
                    if (sym.Type == SymbolType.Label && sym.Value >= vocabStart && sym.Value < position)
                    {
                        sym.Value = MapVocabAddress(sym.Value, newIndexes);
                    }
                }

                if (FinalPass)
                {
                    // check for collisions
                    for (int i = 1; i < records; i++)
                    {
                        if (VocabCompare(buffer, i - 1, i) == 0)
                        {
                            Errors.Warn(this,
                                src,
                                "vocab collision between {0} and {1}",
                                VocabLabel(i - 1) ?? "<null>",
                                VocabLabel(i) ?? "<null>");
                        }
                    }
                }

                stream?.Write(buffer);

                // apply fixups
                var vocabEnd = position;
                var goners = new HashSet<Fixup>();

                foreach (var f in Fixups)
                {
                    if (f.Location >= vocabStart && f.Location < vocabEnd)
                    {
                        if (GlobalSymbols.TryGetValue(f.Symbol, out var sym) &&
                            sym.Type == SymbolType.Label &&
                            sym.Value >= vocabStart && sym.Value < vocabEnd)
                        {
                            Position = MapVocabAddress(f.Location, newIndexes);
                            WriteWord((ushort)sym.Value);
                        }

                        goners.Add(f);
                    }
                }

                Fixups.RemoveAll(f => goners.Contains(f));
                Position = vocabEnd;
            }

            vocabStart = -1;
            vocabRecSize = 0;
            vocabKeySize = 0;
        }

        void VocabMove(Span<byte> buffer, int srcIndex, int destIndex, int recordCount)
        {
            var byteCount = recordCount * vocabRecSize;
            var src = buffer.Slice(srcIndex * vocabRecSize, byteCount);
            var dest = buffer.Slice(destIndex * vocabRecSize, byteCount);
            src.CopyTo(dest);
        }

        Span<byte> VocabRecord(Span<byte> buffer, int index) =>
            buffer.Slice(index * vocabRecSize, vocabRecSize);

        ReadOnlySpan<byte> VocabRecord(ReadOnlySpan<byte> buffer, int index) =>
            buffer.Slice(index * vocabRecSize, vocabRecSize);

        int MapVocabAddress(int oldAddress, int[] newIndexes)
        {
            var oldOffsetFromVocab = oldAddress - vocabStart;
            var oldIndex = oldOffsetFromVocab / vocabRecSize;
            var offsetWithinEntry = oldOffsetFromVocab % vocabRecSize;
            var newIndex = newIndexes[oldIndex];
            return vocabStart + (newIndex * vocabRecSize) + offsetWithinEntry;
        }

        int VocabSearch(ReadOnlySpan<byte> buffer, int numRecs, int keyRec)
        {
            int start = 0, end = numRecs - 1;
            while (start <= end)
            {
                int mid = (start + end) / 2;
                var diff = VocabCompare(buffer, keyRec, mid);
                if (diff == 0)
                    return mid;

                if (diff < 0)
                    end = mid - 1;
                else
                    start = mid + 1;
            }
            return start;
        }

        int VocabCompare(ReadOnlySpan<byte> buffer, int idx1, int idx2) =>
            VocabRecord(buffer, idx1).SequenceCompareTo(VocabRecord(buffer, idx2));

        string? VocabLabel(int index)
        {
            foreach (var sym in GlobalSymbols.Values)
            {
                if (sym.Type == SymbolType.Label && sym.Value >= vocabStart && sym.Value < position)
                {
                    int offset = sym.Value - vocabStart;
                    if (offset % vocabRecSize == 0 && offset / vocabRecSize == index)
                        return sym.Name;
                }
            }

            return "index " + index;
        }

        public void PushFile(string filename)
        {
            if (!Quiet)
                Console.Error.WriteLine("Reading {0}", filename);

            fileStack.Push(filename);
        }

        public void PopFile()
        {
            fileStack.Pop();
        }

        public void OpenOutput()
        {
            Debug.Assert(OutFile != null);

            if (Path.GetExtension(OutFile) == ".z#")
                OutFile = Path.ChangeExtension(OutFile, ".z" + ZVersion);

            position = 0;
            stream = FileSystem.OpenForWritingAndReading(OutFile);
        }

        public void CloseOutput()
        {
            stream?.Close();
            stream = null;
        }

        public void OpenDebugFile()
        {
            Debug.Assert(DebugFile != null);

            var debugStream = FileSystem.OpenForWriting(DebugFile);

            if (InterceptGetDebugWriter != null)
            {
                DebugWriter = InterceptGetDebugWriter(debugStream);

                if (DebugWriter != null)
                    return;
            }

            DebugWriter = XmlDebugMode
                ? (IDebugFileWriter)new XmlDebugFileWriter(debugStream)
                : new BinaryDebugFileWriter(debugStream);
        }

        public void CloseDebugFile()
        {
            DebugWriter?.Close();
            DebugWriter = null;
        }

        public bool IsDebugFileOpen => DebugWriter != null;

        public byte[] GetHeader()
        {
            var op = Position;
            Position = 0;
            try
            {
                var result = new byte[64];

                for (int i = 0; i < 64; i++)
                    result[i] = ReadByte();

                return result;
            }
            finally
            {
                Position = op;
            }
        }

        /// <exception cref="InvalidOperationException" accessor="set">A vocab section is currently being written.</exception>
        public int Position
        {
            get => position;

            set
            {
                position = value;

                if (stream != null)
                {
                    if (InVocab)
                        throw new InvalidOperationException("Cannot seek while inside vocab section");

                    stream.Seek(value, SeekOrigin.Begin);
                }
            }
        }

        public int PackingDivisor
        {
            get
            {
                return ZVersion switch
                {
                    1 or 2 or 3 => 2,
                    4 or 5 or 6 or 7 => 4,
                    8 => 8,
                    _ => throw new NotImplementedException(),
                };
            }
        }

        public int HeaderLengthDivisor
        {
            get
            {
                return ZVersion switch
                {
                    1 or 2 or 3 => 2,
                    4 or 5 => 4,
                    6 or 7 or 8 => 8,
                    _ => throw new NotImplementedException(),
                };
            }
        }

        public bool UsePackingOffsets => ZVersion == 6 || ZVersion == 7;

        public static int PackingOffsetDivisor => 8;

        public void BeginReassemblyScope(int nodeIndex, Symbol symbol)
        {
            reassemblyLabels.Clear();
            deferredGlobalLabelChecks.Clear();
            reassemblyNodeIndex = nodeIndex;
            reassemblyPosition = position;
            reassemblyAbbrevPos = AbbrevFinder.Position;
            reassemblySymbol = symbol;
        }

        public bool CausesReassembly(string label)
        {
            return reassemblyLabels.ContainsKey(label);
        }

        public bool InReassemblyScope => reassemblyPosition != -1;

        public void MarkUnknownBranch(string label)
        {
            reassemblyLabels[label] = true;
        }

        public void DeferGlobalLabelStabilityCheck(Symbol sym, Action checkMismatch)
        {
            if (!deferredGlobalLabelChecks.ContainsKey(sym))
            {
                deferredGlobalLabelChecks.Add(sym, checkMismatch);
            }
        }

        public int Reassemble(string curLabel)
        {
            if (LocalSymbols.TryGetValue(curLabel, out var sym))
                sym.Value = position;
            else
                LocalSymbols.Add(curLabel, new Symbol(curLabel, SymbolType.Label, position));

            // save labels as phantoms, wipe all other local symbols
            var goners = new Queue<string>();

            foreach (var i in LocalSymbols.Values)
            {
                if (i.Type == SymbolType.Label)
                {
                    i.Phantom = true;
                }
                else
                {
                    Debug.Assert(i.Name != null);
                    goners.Enqueue(i.Name);
                }
            }

            while (goners.Count > 0)
                LocalSymbols.Remove(goners.Dequeue());

            // make function symbol into a phantom
            reassemblySymbol!.Phantom = true;

            // clean up reassembly state and rewind to the beginning of the scope
            reassemblyLabels.Clear();
            deferredGlobalLabelChecks.Clear();
            Position = reassemblyPosition;
            AbbrevFinder.Rollback(reassemblyAbbrevPos);
            DebugWriter?.RestartRoutine();
            return reassemblyNodeIndex;
        }

        public void EndReassemblyScope(int nodeIndex)
        {
            if (nodeIndex != reassemblyNodeIndex)
            {
                reassemblyLabels.Clear();
                reassemblyNodeIndex = -1;
                reassemblyPosition = -1;
                reassemblyAbbrevPos = 0;
                reassemblySymbol = null;
                LocalSymbols.Clear();

                try
                {
                    foreach (var runDeferredCheck in deferredGlobalLabelChecks.Values)
                        runDeferredCheck();
                }
                finally
                {
                    deferredGlobalLabelChecks.Clear();
                }
            }
        }

        /// <exception cref="SeriousError">The global variable moved unexpectedly between passes.</exception>
        public void AddGlobalVar(string name)
        {
            int num = 16 + globalVarCount++;

            if (GlobalSymbols.TryGetValue(name, out var sym) == false)
            {
                sym = new Symbol(name, SymbolType.Variable, num);
                GlobalSymbols.Add(name, sym);
            }
            else if (sym!.Phantom && sym.Type == SymbolType.Variable)
            {
                if (sym.Value != num)
                {
                    Errors.ThrowSerious("global {0} seems to have moved: was {1}, now {2}", name, sym.Value, num);
                }

                sym.Phantom = false;
            }
            else if (sym.Type == SymbolType.Unknown)
            {
                sym.Type = SymbolType.Variable;
                sym.Value = num;
                MeasureAgain = true;
            }
            else
            {
                Errors.ThrowSerious("global redefined: " + name);
            }
        }

        /// <exception cref="FatalError">The object moved unexpectedly between passes.</exception>
        /// <exception cref="SeriousError">The object was redefined.</exception>
        public void AddObject(string name)
        {
            int num = 1 + objectCount++;

            if (GlobalSymbols.TryGetValue(name, out var sym) == false)
            {
                sym = new Symbol(name, SymbolType.Object, num);
                GlobalSymbols.Add(name, sym);
            }
            else if (sym!.Phantom && sym.Type == SymbolType.Object)
            {
                if (sym.Value != num)
                {
                    Errors.ThrowFatal("object {0} seems to have moved: was {1}, now {2}", name, sym.Value, num);
                }

                sym.Phantom = false;
            }
            else if (sym.Type == SymbolType.Unknown)
            {
                sym.Type = SymbolType.Object;
                sym.Value = num;
                MeasureAgain = true;
            }
            else
            {
                Errors.ThrowSerious("object redefined: " + name);
            }
        }

        public void CheckLimits()
        {
            if (globalVarCount > 240)
                Errors.Serious(this, "too many global variables: {0} defined, only 240 allowed", globalVarCount);

            var maxObjects = (ZVersion == 3 ? 255 : 65535);
            if (objectCount > maxObjects)
                Errors.Serious(this, "too many objects: {0} defined, only {1} allowed", objectCount, maxObjects);
        }

        public void CheckForUndefinedSymbols()
        {
            // define FOFF and SOFF for V6-7
            if (UsePackingOffsets)
            {
                GlobalSymbols["FOFF"] = new Symbol("FOFF", SymbolType.Constant, FunctionsOffset / PackingOffsetDivisor);
                GlobalSymbols["SOFF"] = new Symbol("SOFF", SymbolType.Constant, StringsOffset / PackingOffsetDivisor);
            }

            // define FLAGS and RELEASEID if needed
            void SetConstantDefault(string name, ushort value)
            {
                if (GlobalSymbols.TryGetValue(name, out var sym) && sym.Type == SymbolType.Unknown)
                {
                    sym.Type = SymbolType.Constant;
                    sym.Value = value;
                }
            }

            SetConstantDefault("FLAGS", 0);

            var releaseId = (ushort)GetHeaderValue("RELEASEID", "ZORKID", false);
            SetConstantDefault("RELEASEID", releaseId);
            SetConstantDefault("ZORKID", releaseId);

            // now look for any remaining undefined symbols
            var offenders = new HashSet<string>();

            foreach (var f in Fixups)
            {
                if (!GlobalSymbols.ContainsKey(f.Symbol) && !offenders.Contains(f.Symbol))
                {
                    Errors.Serious(this, "symbol is never defined: {0}", f.Symbol);
                    offenders.Add(f.Symbol);
                }
            }
        }

        public void ResetBetweenPasses()
        {
            Fixups.Clear();
            StringEncoder = new StringEncoder();

            foreach (var sym in GlobalSymbols.Values)
                sym.Phantom = true;

            globalVarCount = 0;
            objectCount = 0;

            FunctionsOffset = 0;
            StringsOffset = 0;
        }

        public void HandleWarning(Warning warning)
        {
            WarningCount++;

            if (warning.Node != null)
                Console.Error.Write("{0}:{1}: ", warning.Node.SourceFile, warning.Node.LineNum);

            Console.Error.WriteLine("warning: {0}", warning.Message);
        }

        public void HandleSeriousError(SeriousError ser)
        {
            ErrorCount++;

            if (ser.Node != null)
                Console.Error.Write("{0}:{1}: ", ser.Node.SourceFile, ser.Node.LineNum);

            Console.Error.WriteLine("error: {0}", ser.Message);
        }

        public void HandleFatalError(FatalError fer)
        {
            ErrorCount++;

            if (fer.Node != null)
                Console.Error.Write("{0}:{1}: ", fer.Node.SourceFile, fer.Node.LineNum);

            Console.Error.WriteLine("fatal error: {0}", fer.Message);
        }

        public string? FindInsertedFile(string name)
        {
            if (FileSystem.Exists(name))
                return name;

            string search = name + ".zap";
            if (FileSystem.Exists(search))
                return search;

            search = name + ".xzap";
            if (FileSystem.Exists(search))
                return search;

            return null;
        }

        public void SetLanguage(int langId, int escapeChar)
        {
            LanguageEscapeChar = (char)escapeChar;

            LanguageSpecialChars.Clear();
            switch (langId)
            {
                case 1:
                    // German
                    LanguageSpecialChars.Add('a', 'ä');
                    LanguageSpecialChars.Add('o', 'ö');
                    LanguageSpecialChars.Add('u', 'ü');
                    LanguageSpecialChars.Add('s', 'ß');
                    LanguageSpecialChars.Add('A', 'Ä');
                    LanguageSpecialChars.Add('O', 'Ö');
                    LanguageSpecialChars.Add('U', 'Ü');
                    LanguageSpecialChars.Add('<', '«');
                    LanguageSpecialChars.Add('>', '»');
                    break;
            }
        }

        public void Dispose()
        {
            try
            {
                stream?.Dispose();
                prevStream?.Dispose();
            }
            finally
            {
                stream = null;
                prevStream = null;
            }
        }

        public int GetHeaderValue(string name, bool required) => GetHeaderValue(name, null, required);

        public int GetHeaderValue(string name1, string? name2, bool required)
        {
            if (GlobalSymbols.TryGetValue(name1, out var sym) ||
                (name2 != null && GlobalSymbols.TryGetValue(name2, out sym)))
            {
                return sym.Type switch
                {
                    SymbolType.Label or SymbolType.Function or SymbolType.Constant => sym.Value,
                    _ => 0,
                };
            }

            if (required)
                Errors.Serious(this, "required global symbol '{0}' is missing", name1);
            return 0;
        }
    }
}
