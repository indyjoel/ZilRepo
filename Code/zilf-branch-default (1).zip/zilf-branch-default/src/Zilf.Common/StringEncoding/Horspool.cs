﻿/* Copyright 2010-2023 Tara McGrew
 * 
 * This file is part of ZILF.
 * 
 * ZILF is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * ZILF is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with ZILF.  If not, see <http://www.gnu.org/licenses/>.
 */

using System;
using System.Collections.Generic;
using System.Text;

namespace Zilf.Common.StringEncoding
{
    /// <summary>
    /// Implements the Boyer-Moore-Horspool algorithm for abbreviation searches.
    /// </summary>
    /// <remarks>http://en.wikipedia.org/wiki/Boyer-Moore-Horspool_algorithm</remarks>
    public class Horspool
    {
        readonly string needle;
        readonly CharMap badCharSkip;

        public Horspool(string needle)
        {
            if (string.IsNullOrEmpty(needle))
                throw new ArgumentException("Search string must not be empty", nameof(needle));

            this.needle = needle;

            int nlen = needle.Length;
            badCharSkip = new CharMap(nlen);

            int last = nlen - 1;
            for (int i = 0; i < last; i++)
                badCharSkip[needle[i]] = last - i;
        }

        public string Text => needle;

        public int FindIn(ReadOnlySpan<char> haystack, int startIndex = 0)
        {
            int hlen = haystack.Length - startIndex;
            int hstart = startIndex;
            int nlen = needle.Length;
            int last = nlen - 1;

            while (hlen >= nlen)
            {
                for (int i = last; haystack[hstart + i] == needle[i]; i--)
                    if (i == 0)
                        return hstart;

                int skip = badCharSkip[haystack[hstart + last]];
                hlen -= skip;
                hstart += skip;
            }

            return -1;
        }

        public int FindIn(StringBuilder haystack, int startIndex = 0)
        {
            int hlen = haystack.Length - startIndex;
            int hstart = startIndex;
            int nlen = needle.Length;
            int last = nlen - 1;

            while (hlen >= nlen)
            {
                for (int i = last; haystack[hstart + i] == needle[i]; i--)
                    if (i == 0)
                        return hstart;

                int skip = badCharSkip[haystack[hstart + last]];
                hlen -= skip;
                hstart += skip;
            }

            return -1;
        }

        class CharMap
        {
            readonly int[] small = new int[256];
            Dictionary<char, int>? big;

            public CharMap(int defaultValue)
            {
                DefaultValue = defaultValue;

                for (int i = 0; i < 256; i++)
                    small[i] = defaultValue;
            }

            int DefaultValue { get; }

            public int this[char c]
            {
                get
                {
                    if (c < (char)256)
                        return small[c];

                    if (big == null || big.TryGetValue(c, out int result) == false)
                        return DefaultValue;

                    return result;
                }
                set
                {
                    if (c < (char)256)
                    {
                        small[c] = value;
                    }
                    else
                    {
                        big ??= new Dictionary<char, int>();

                        big[c] = value;
                    }
                }
            }
        }
    }
}
