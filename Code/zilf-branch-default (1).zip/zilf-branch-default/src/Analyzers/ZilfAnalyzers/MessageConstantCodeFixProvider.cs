﻿/* Copyright 2010-2023 Tara McGrew
 * 
 * This file is part of ZILF.
 * 
 * ZILF is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * ZILF is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with ZILF.  If not, see <http://www.gnu.org/licenses/>.
 */

using System.Collections.Immutable;
using System.Composition;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CodeActions;
using Microsoft.CodeAnalysis.CodeFixes;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.CodeAnalysis.FindSymbols;
using Microsoft.CodeAnalysis.Rename;

namespace ZilfAnalyzers
{
    [ExportCodeFixProvider(LanguageNames.CSharp, Name = nameof(MessageConstantCodeFixProvider)), Shared]
    public class MessageConstantCodeFixProvider : CodeFixProvider
    {
        const string Title = "Move prefix to call sites";

        public sealed override ImmutableArray<string> FixableDiagnosticIds => ImmutableArray.Create(
            DiagnosticIds.PrefixedMessageFormat);

        public sealed override FixAllProvider GetFixAllProvider()
        {
            return WellKnownFixAllProviders.BatchFixer;
        }

        public sealed override async Task RegisterCodeFixesAsync(CodeFixContext context)
        {
            var root = await context.Document.GetSyntaxRootAsync(context.CancellationToken).ConfigureAwait(false);

            if (root == null)
                return;

            // we can only fix PrefixedMessageFormat
            var diagnostic = context.Diagnostics.FirstOrDefault(d => d.Id == DiagnosticIds.PrefixedMessageFormat);

            if (diagnostic == null)
                return;

            var diagnosticSpan = diagnostic.Location.SourceSpan;

            var formatExpr = root.FindToken(diagnosticSpan.Start).Parent?.AncestorsAndSelf().OfType<AttributeArgumentSyntax>().First().Expression;

            if (formatExpr == null)
                return;

            var fieldDecl = formatExpr.AncestorsAndSelf().OfType<FieldDeclarationSyntax>().First();

            if (fieldDecl.Declaration.Variables.Count != 1)
                return;

            // Register a code action that will invoke the fix.
            context.RegisterCodeFix(
                CodeAction.Create(
                    title: Title,
                    createChangedSolution: c => MoveMessagePrefixToCallSitesAsync(context.Document, fieldDecl, c),
                    equivalenceKey: Title),
                diagnostic);
        }

        record class PendingReplacement(Document Document, SyntaxNode Old, SyntaxNode New);

        static async Task<Solution> MoveMessagePrefixToCallSitesAsync(Document document,
            FieldDeclarationSyntax fieldDecl, CancellationToken cancellationToken)
        {
            // TODO: simplify this using SyntaxEditor?

            var messageDocId = document.Id;

            // we'll need to track the field across renames
            var fieldDeclAnnotation = new SyntaxAnnotation();
            var root = await document.GetSyntaxRootAsync(cancellationToken);
            document = document.WithSyntaxRoot(
                root!.ReplaceNode(
                    fieldDecl,
                    fieldDecl.WithAdditionalAnnotations(fieldDeclAnnotation)));
            var solution = document.Project.Solution;

            SemanticModel? semanticModel;

            FieldDeclarationSyntax FindFieldDecl(SyntaxNode node)
            {
                return node.DescendantNodes()
                    .OfType<FieldDeclarationSyntax>()
                    .Single(n => n.HasAnnotation(fieldDeclAnnotation));
            }

            ExpressionSyntax FindFormatExpr(SyntaxNode node)
            {
                return FindFieldDecl(node)
                    .DescendantNodes()
                    .OfType<AttributeSyntax>()
                    .First(a => MessageConstantAnalyzer.IsMessageAttribute(semanticModel, a))
                    .DescendantNodes()
                    .OfType<AttributeArgumentSyntax>()
                    .First()
                    .Expression;
            }

            // get format string and split it into prefix + rest
            semanticModel = await document.GetSemanticModelAsync(cancellationToken);
            root = await document.GetSyntaxRootAsync(cancellationToken);
            var formatStr = (string?)semanticModel!.GetConstantValue(FindFormatExpr(root!), cancellationToken).Value;
            Debug.Assert(formatStr != null);
            var match = MessageConstantAnalyzer.PrefixedMessageFormatRegex.Match(formatStr);
            var prefix = match.Groups["prefix"].Value;
            var rest = match.Groups["rest"].Value;

            var newFormatStr = "{0}" + ErrorExceptionUsageAnalyzer.IncrementFormatTokens(rest);

            // replace format string
            var newFormatExpr = SyntaxFactory.LiteralExpression(
                SyntaxKind.StringLiteralExpression,
                SyntaxFactory.Literal(newFormatStr));

            var pendingReplacements = ImmutableList.Create(
                new PendingReplacement(document, FindFormatExpr(root!), newFormatExpr));

            async Task ApplyPendingReplacementsAsync()
            {
                // ReSharper disable AccessToModifiedClosure
                var replacementsByDocument = pendingReplacements.GroupBy(pr => pr.Document);
                pendingReplacements = pendingReplacements.Clear();

                foreach (var group in replacementsByDocument)
                {
                    var syntaxMapping = group.ToDictionary(pr => pr.Old, pr => pr.New);

                    var syntaxRoot = await group.Key.GetSyntaxRootAsync(cancellationToken);
                    Debug.Assert(syntaxRoot != null);
                    var newSyntaxRoot = syntaxRoot.ReplaceNodes(syntaxMapping.Keys, (node, _) => syntaxMapping[node]);

                    solution = solution.WithDocumentSyntaxRoot(group.Key.Id, newSyntaxRoot);
                }
                // ReSharper restore AccessToModifiedClosure
            }

            root = await document.GetSyntaxRootAsync(cancellationToken);
            var fieldSymbol = semanticModel.GetDeclaredSymbol(
                FindFieldDecl(root!).Declaration.Variables[0],
                cancellationToken);

            if (fieldSymbol != null)
            {
                // rename constant if the name matches the old message format
                if (fieldSymbol.Name == ErrorExceptionUsageCodeFixProvider.GetConstantNameFromMessageFormat(formatStr))
                {
                    await ApplyPendingReplacementsAsync();

                    var newCompilation = await solution.GetDocument(messageDocId)!.Project.GetCompilationAsync(cancellationToken);
                    fieldSymbol = SymbolFinder.FindSimilarSymbols(fieldSymbol, newCompilation, cancellationToken).First();

                    var newName = ErrorExceptionUsageCodeFixProvider.GetConstantNameFromMessageFormat(newFormatStr);
                    solution = await Renamer.RenameSymbolAsync(solution, fieldSymbol, newName,
                        solution.Workspace.Options, cancellationToken);

                    var newDocument = solution.GetDocument(messageDocId);
                    var newRoot = await newDocument!.GetSyntaxRootAsync(cancellationToken);
                    var newFieldDecl = FindFieldDecl(newRoot!);
                    var newSemanticModel = await newDocument.GetSemanticModelAsync(cancellationToken);
                    fieldSymbol = newSemanticModel.GetDeclaredSymbol(newFieldDecl.Declaration.Variables[0], cancellationToken);
                }

                // update call sites
                var prefixSyntax = SyntaxFactory.LiteralExpression(
                    SyntaxKind.StringLiteralExpression,
                    SyntaxFactory.Literal(prefix));

                var references = await SymbolFinder.FindReferencesAsync(fieldSymbol, solution, cancellationToken);
                var rs = references.SingleOrDefault();

                if (rs != null)
                {
                    foreach (var location in rs.Locations.Where(l => !l.IsCandidateLocation && !l.IsImplicit))
                    {
                        var replacement = await ReplacementCallSiteWithPrefixInsertedAsync(location, prefixSyntax, cancellationToken);
                        if (replacement != null)
                            pendingReplacements = pendingReplacements.Add(replacement);
                    }
                }
            }

            // apply pending replacements
            await ApplyPendingReplacementsAsync();

            return solution;
        }

        static async Task<PendingReplacement?> ReplacementCallSiteWithPrefixInsertedAsync(
            ReferenceLocation location, LiteralExpressionSyntax prefixSyntax, CancellationToken cancellationToken)
        {
            var root = await location.Document.GetSyntaxRootAsync(cancellationToken);

            if (root?.FindToken(location.Location.SourceSpan.Start).Parent?.Parent is not MemberAccessExpressionSyntax accessExpr)
                return null;

            var argumentListExpr = accessExpr.FirstAncestorOrSelf<ArgumentListSyntax>();
            if (argumentListExpr == null)
                return null;

            var accessIdx = argumentListExpr.Arguments.IndexOf(a => a.Expression == accessExpr);
            if (accessIdx < 0)
                return null;

            var newArgumentListExpr = argumentListExpr.WithArguments(
                argumentListExpr.Arguments.Insert(
                    accessIdx + 1,
                    SyntaxFactory.Argument(prefixSyntax)));

            return new PendingReplacement(location.Document, argumentListExpr, newArgumentListExpr);
        }
    }
}