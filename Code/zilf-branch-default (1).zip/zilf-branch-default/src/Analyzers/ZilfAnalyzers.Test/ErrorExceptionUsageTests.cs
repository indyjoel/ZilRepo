﻿/* Copyright 2010-2023 Tara McGrew
 * 
 * This file is part of ZILF.
 * 
 * ZILF is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * ZILF is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with ZILF.  If not, see <http://www.gnu.org/licenses/>.
 */

using System.Threading.Tasks;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CodeFixes;
using Microsoft.CodeAnalysis.Diagnostics;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ZilfAnalyzers.Test.Helpers;
using CodeFixVerifier = ZilfAnalyzers.Test.Helpers.CodeFixVerifier;

namespace ZilfAnalyzers.Test
{
    [TestClass, TestCategory("Analyzers")]
    [TestCategory("Slow")]
    public class ErrorExceptionUsageTests : CodeFixVerifier
    {
        //No diagnostics expected to show up
        [TestMethod]
        public async Task ErrorExceptionUsageAnalyzer_NotTriggeredAsync()
        {
            var test = @"";

            await VerifyCSharpDiagnosticAsync(test);
        }

        //Diagnostic and CodeFix both triggered and checked for
        [TestMethod]
        public async Task ErrorExceptionUsageAnalyzer_TriggeredAndFixedAsync()
        {
            var test = @"
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using Zilf.Diagnostics;
using Zilf.Language;

namespace Zilf.Language {
    class InterpreterError : Exception {
        public InterpreterError(string s) {}
        public InterpreterError(int i, params object[] args) {}
    }
}

namespace Zilf.Diagnostics {
    [AttributeUsage(AttributeTargets.Field)]
    class MessageAttribute : Attribute {
        public MessageAttribute(string s) {}
    }

    class InterpreterMessages {
        public const int Foo = 1;
    }
}

class Program {
    void Main(string a, object b) {
        throw new InterpreterError(""bad stuff"");
        throw new InterpreterError(string.Format(""{0} is a problem"", 1));
        throw new InterpreterError(""LOOK: I also object to "" + a + "" and "" + b);
    }
}
";
            var expected = new[] {
                new DiagnosticResult
                {
                    Id = "ZILF0001",
                    Message = "This exception should use a diagnostic code instead",
                    Severity = DiagnosticSeverity.Warning,
                    Locations = [new DiagnosticResultLocation("Test0.cs", 31, 15)]
                },
                new DiagnosticResult
                {
                    Id = "ZILF0001",
                    Message = "This exception should use a diagnostic code instead",
                    Severity = DiagnosticSeverity.Warning,
                    Locations = [new DiagnosticResultLocation("Test0.cs", 32, 15)]
                },                new DiagnosticResult
                {
                    Id = "ZILF0001",
                    Message = "This exception should use a diagnostic code instead",
                    Severity = DiagnosticSeverity.Warning,
                    Locations = [new DiagnosticResultLocation("Test0.cs", 33, 15)]
                }
            };

            await VerifyCSharpDiagnosticAsync(test, expected);

            var fixtest = @"
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using Zilf.Diagnostics;
using Zilf.Language;

namespace Zilf.Language {
    class InterpreterError : Exception {
        public InterpreterError(string s) {}
        public InterpreterError(int i, params object[] args) {}
    }
}

namespace Zilf.Diagnostics {
    [AttributeUsage(AttributeTargets.Field)]
    class MessageAttribute : Attribute {
        public MessageAttribute(string s) {}
    }

    class InterpreterMessages {
        public const int Foo = 1;
        [Message(""bad stuff"")]
        public const int Bad_Stuff = 2;
        [Message(""{0} is a problem"")]
        public const int _0_Is_A_Problem = 3;
        [Message(""{0}: I also object to {1} and {2}"")]
        public const int _0_I_Also_Object_To_1_And_2 = 4;
    }
}

class Program {
    void Main(string a, object b) {
        throw new InterpreterError(InterpreterMessages.Bad_Stuff);
        throw new InterpreterError(InterpreterMessages._0_Is_A_Problem, 1);
        throw new InterpreterError(InterpreterMessages._0_I_Also_Object_To_1_And_2, ""LOOK"", a, b);
    }
}
";
            await VerifyCSharpFixAsync(test, fixtest);
        }

        [TestMethod]
        public async Task ErrorExceptionUsageAnalyzer_DontFlagWhenFirstArgIsAlreadyACodeAsync()
        {
            var test = @"
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using Zilf.Diagnostics;
using Zilf.Language;

namespace Zilf.Language {
    class InterpreterError : Exception {
        public InterpreterError(string s) {}
        public InterpreterError(int i) {}
    }
}

namespace Zilf.Diagnostics {
    [AttributeUsage(AttributeTargets.Field)]
    class MessageAttribute : Attribute {
        public MessageAttribute(string s) {}
    }

    class InterpreterMessages {
        [Message(""I don't like '{0}'"")]
        public const int NoThanks = 1;
    }
}

class Program {
    void Main() {
        throw new InterpreterError(InterpreterMessages.NoThanks, ""spam"");
    }
}
";

            await VerifyCSharpDiagnosticAsync(test);
        }

        protected override CodeFixProvider GetCSharpCodeFixProvider()
        {
            return new ErrorExceptionUsageCodeFixProvider();
        }

        protected override CodeFixProvider GetBasicCodeFixProvider()
        {
            throw new System.NotImplementedException();
        }

        protected override DiagnosticAnalyzer GetCSharpDiagnosticAnalyzer()
        {
            return new ErrorExceptionUsageAnalyzer();
        }

        protected override DiagnosticAnalyzer GetBasicDiagnosticAnalyzer()
        {
            throw new System.NotImplementedException();
        }
    }
}