********
Glossary
********

.. glossary::
  :sorted:

  routine
  routines

    An executable function containing |ZMachine| code. Routines are
    almost always defined with :function:`ROUTINE`, turned into Z-code by
    the compiler, and stored in `static memory`:term:.

    At runtime, routines are referred to by `packed addresses`:term:.

  dynamic memory

    Memory that's initialized from the `story file`:term:, but which the game
    can alter during execution. Also known as `RAM (Random Access Memory)`:abbr:
    or impure memory.

  static memory

    Memory that's initialized from the `story file`:term: and cannot be
    changed during execution. Also known as `ROM (Read-Only Memory)`:abbr: or
    pure memory.

  story file

    A compiled game file containing bytecode to be run on a `ZIP`:term:. Modern
    files usually have an extension indicating their |ZMachine| version, such as
    ".Z3" or ".Z8". Infocom files usually had the extension ".DAT".

  ZIP
  Zork Interpreter Program

    Infocom's name for their interpreter, the program that implemented the
    |ZMachine| for home computers.

  packed address
  packed addresses

    An address in |ZMachine| memory -- generally `static memory`:term: --
    which has been arithmetically transformed to allow a larger effective
    address space.

    `Encoded strings`:term: are expressed as packed addresses, except in the
    `abbreviations`:term: table.

    `Routines`:term: are expressed as packed addresses, except for the
    address of the `GO` routine in the `header`:term: in `V1-5`:zmachine:.
