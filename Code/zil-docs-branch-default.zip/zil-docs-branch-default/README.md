# README #

### What is this? ###

This is a repository for documentation related to [ZILF](https://foss.heptapod.net/zilf/zilf).

For now, you're probably better off using [Henrik Åsman's ZILF Reference Guide](https://github.com/heasm66/ZILF-Reference-Guide) and the other documents listed in the [wiki](https://foss.heptapod.net/zilf/zilf/-/wikis/Getting-Started#documentation).

### What else do I need to know? ###

This project's ongoing development is made possible by the hosting services generously provided by [Octobus](https://octobus.net/) and [Clever Cloud](https://www.clever-cloud.com/).
