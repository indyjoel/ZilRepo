************
Introduction
************

|sdfsd|

This document describes `ZIL`:dfn:, the programming language Infocom used to
write their interactive fiction titles. The original documentation and tools
are no longer available, but the language has been reimplemented for modern use
in the form of `ZILF (The ZIL Implementfation You Really Like)`:abbr:.
[#zilfoss]_

.. index:: ZIP, Z-machine, story file

`ZIL`:dfn: stands for Zork Implementation Language, as it was developed to fit
Zork – originally written for a DEC mainframe – into the tiny home computers of
the early 1980s. The compiled form of a ZIL program is a platform-independent
executable, or `story file`:dfn:, for a virtual machine called the
`Z-machine`:dfn:, which is emulated by a platform-specific program called
`ZIP`:program:. [#zipnaming]_

A full discussion of the influences and design constraints that went into the
development of ZIL is beyond the scope of this document. However, to understand
ZIL, one should know the following:

  * .. index:: MDL

    Zork was originally written in a Lisp-like general purpose language called
    `MDL`:dfn:. [#mdlnaming]_

  * MDL can be used "conversationally" [#mdlrepl]_, i.e. in an interactive mode
    where the user enters an MDL expression, MDL evaluates it and immediately
    prints a response. A program written in MDL has access to the same features
    that MDL itself uses to parse and evaluate these expressions.

  * .. index:: ZILCH

    Infocom's ZIL compiler, called `ZILCH`:program:, was written in MDL.
    Although the home systems on which the Zork series ran didn't have enough
    power or memory to implement many features of MDL, the mainframes on which
    `ZILCH`:program: ran did, and thus ZIL code can take advantage of those
    features.

  * In fact, there's significant overlap between MDL and ZIL, with no clear
    boundary separating the two languages. One could view `ZILCH`:program: as a
    set of extensions to the MDL interpreter which allowed it to produce code
    for `ZIP`:program:, and thus view the ZIL language as an extension of MDL.

.. [#zilfoss] https://bitbucket.org/jmcgrew/zilf/

.. [#zipnaming] Infocom used the name `ZIP (Z-machine Interpreter Program)`:dfn:
  through version 3 of the Z-machine.

  Later versions were known as `EZIP`:program: (version 4), `XZIP`:program:
  (version 5), and `YZIP`:program: (version 6).

  Infocom's original `ZIP`:program:\ s generally aren't used anymore, since the
  modern interactive fiction community reverse-engineered and reimplemented the
  Z-machine after Infocom's demise. Today, these programs are more often just
  called `interpreters`:dfn:.

.. [#mdlnaming] `MDL`:abbr: theoretically stood for MIT Design Language, but it
   was actually a backronym chosen to cover up the self-deprecating humor of
   the original name, `MUDDLE`:program:.

.. [#mdlrepl] .. index:: REPL

   "Conversational" mode is also known as :abbr:`REPL\
   (Read-Evaluate-Print Loop)`.

This document describes ZIL from two perspectives:

  * The **Shiny Surface**, comprising the parts that translate directly into
    structures used by ZIP – global variables, tables, objects, vocabulary
    and grammar, and routines – as well as high-level directives that
    control how the game is compiled.

    Game designers who could base their new works on existing games,
    without needing to make any low-level changes to the "substrate",
    would only need to know about the Shiny Surface.

  * The **Dark Underbelly**, comprising the entire subset of MDL that a
    programmer would need to know in order to modify a game's substrate, or
    that a compiler would need to implement in order to successfully compile
    a game. Luckily for programmers and compilers, this does not include
    many of the more esoteric features of MDL (such as memory management,
    coroutines and continuations, and network I/O) which will not be
    discussed here.

To be clear, the descriptions above refer to the presumed practices of the
Infocom era. Knowledge of the Dark Underbelly is not required for writing a new
game from scratch; although the Dark Underbelly is convenient for making macros
that allow for higher-level code, one can get by with only the Shiny Surface.

.. topic:: Terminology: ZIL vs. MDL vs. Z-code

  In this document, the term "ZIL" refers to the complete language, both
  Shiny Surface and Dark Underbelly.

  "ZIP instructions" and "Z-code" refer to the subset of the language used
  inside `routine`:term: definitions, which translates almost directly into
  Z-machine opcodes.

  "MDL" refers to the subset of MDL implemented in ZILF, and more generally to
  code that's interpreted by ZILF while a game is being compiled, rather than
  by a ZIP while the game is running.

  "ZIP" generally refers to whichever program is running the compiled game.
