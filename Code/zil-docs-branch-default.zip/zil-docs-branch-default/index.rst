.. zil-language-guide documentation master file

ZIL Language Guide
==================

:Author:
  Jesse McGrew
:ZILF Version:
  0.8
:Revision:
  November 2017

.. default-domain:: zil

.. package:: ZILFLIB

.. function:: <COND (condition1 body1 ...) (condition2 body2 ...) [(ELSE bodyN ...)]>
  :fsubr:

  Evaluates each ``condition`` in order, and runs the corresponding ``body`` of
  the first ``condition`` that evaluates to true. This is equivalent to "if" or
  "switch" in other languages.

  Since an :t:`ATOM` always evaluates to true, it is customary to use a
  ``condition`` of `ELSE` or `T` to introduce a "default" clause, which will
  run if no previous clause has matched. If a "default" clause runs, no
  following clause will run; ZILF will issue :warning:`ZIL0505` if there are
  any more clauses following a default clause.

::

  # TYPE_WITH_UNDERSCORES "Primitive with spaces"

  123 ATOM 456 (LIST) 789

  <ROUTINE FOO (X Y "OPT" (Z W) "AUX" J K (L </ ,M 2>))
    #DECL ((X Y) FIX (J) !<LIST [REST FIX]>)
    ;<THIS IS COMMENTED OUT
      %<THIS ACTUALLY STILL RUNS
        ;<NOT THIS>>>
    <SET X <+ .Y .Z !.J>>>

  ( SPACE LIST )

  ATOM!-IN!-OBLIST!- NOT-IN ATOM!-IN!-OBLIST!-END

  !<SEGMENT> ATOM !<SEGMENT> ATOM

  ATOM ;COMMENT ATOM ;COMMENT ATOM ;COMMENT

  (LIST LIST) ;(COMMENT COMMENT) (LIST LIST) ;(COMMENT COMMENT)

  .LVAL ATOM ,GVAL ATOM <FORM> ATOM .LVAL

  ;!.COMMENTED-SEG-LVAL ;!,COMMENTED-SEG-GVAL ;!.COMMENTED-SEG-LVAL ;!,COMMENTED-SEG-GVAL

.. literalinclude:: sample.zil
  :language: zil

.. literalinclude:: advent.zil
  :linenos:

..

.. toctree::
   :maxdepth: 3
   :numbered:

   01-intro
   02-shiny-surface
   03-dark-underbelly
   90-appendix
   95-glossary

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
