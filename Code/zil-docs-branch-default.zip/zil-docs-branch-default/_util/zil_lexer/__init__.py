# from .lexer import ZilLexer
from .lexer2 import ZilLexer

__all__ = ['ZilLexer']
