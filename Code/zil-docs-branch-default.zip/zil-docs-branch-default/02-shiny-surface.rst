*****************
The Shiny Surface
*****************

This chapter describes ZIL from the perspective of a game author: either one
who is basing a new work on an existing one, and thus has a "substrate" to
work from that needs no modification, or one who is writing a small work from
scratch and is content without conveniences like macros that would be demanded
by larger works or series.

This is, therefore, not a full description of ZIL. The reader may notice odd
coincidences or omissions hinting at the existence of something deeper: that
is exactly the case. For a more complete explanation, read the following
chapter about :ref:`DarkUnderbelly`.

General Syntax
==============

A ZIL program consists of a series of expressions, some of which may
recursively contain other expressions. Some types of expressions include:


.. list-table::
  :header-rows: 1
  :widths: 10, 30, 70

  * - Type
    - Examples
    - Description
  * - :t:`FIX`
    - `123`

      `*377*`

      `#2 1010`
    - An integer. May be given in decimal, octal, or binary as seen here.
  * - :t:`STRING`
    - `"hello"`
    - A piece of text enclosed in double quotes.
  * - :t:`LIST`
    - `(1 2 (3 4 5))`
    - A series of expressions.
  * - :t:`FORM`
    - `<+ 1 2 3>`
    - An instruction that produces a value, or causes something to happen.
  * - :t:`ATOM`
    - `FOO`

      `+`

      `FREQUENT-WORDS?`
    - A name or symbol that identifies something (like an operation, variable,
      object, or value).
  * - Comment
    - `;"this part is tricky"`

      `;<COND (,DEBUG <RETURN>)>`
    - Ignored by the compiler. Note that the thing after `;` is a complete
      expression, so this can be used to comment out an entire :t:`LIST` or
      :t:`FORM`.

An Example Program
==================

This is a simple but complete ZIL program that can be compiled into a working
"game"::

  "Hello World sample"

  <ROUTINE GO ()
      <PRINTI "Hello, world!">
      <CRLF>>

Note the first line: a string that isn't inside any other expression can be
used as a comment.

This program consists of a single routine, named `GO`. Every program must have
a `GO` routine in order to be compiled to Z-code, since it is the first
routine executed by the interpreter.

Inside that routine are two statements, one that prints a message and another
that prints a carriage return. Each statement is a `FORM`:t:, wrapped in
balanced angle brackets: the second bracket after `<CRLF>` ends the `FORM`:t:
that started before `<ROUTINE GO ...`.

When this program is compiled to Z-code and run in an interpreter, it will
print the message "Hello, world!" followed by a line break, and then quit.

Directives
==========

These control the compilation process and should be placed at top level (i.e.
not inside a routine or any other expression).

`<VERSION {code}>`:samp:

  Sets the version of the Z-machine that will be targeted. Acceptable values
  for :param:`code` are the numbers 3 through 8, or the atoms `ZIP`, `EZIP`,
  `XZIP`, or `YZIP` (meaning version 3, 4, 5, and 6, respectively).

  The choice of Z-machine version affects the ZIP instructions that will be
  allowed in routines, the maximum size of the game (number of objects, amount
  of code and text, etc.), and the availability of features like undo, custom
  status lines, graphics, and sound. For more information, see the
  |ZStandard|_.

`<CONSTANT RELEASEID {number}>`:samp:

  Sets the game's release number.

`<INSERT-FILE {"filename"}>`:samp:

  Includes another file. If the file's extension is omitted, ".ZIL" will be
  assumed.

  This is useful for splitting a game up into multiple files: typically there
  will be one "main" file that includes other files containing the parser,
  verb definitions, objects (possibly multiple files for various regions of
  the game), and so on.

`<FREQUENT-WORDS?>`:samp:

  Indicates that the compiler and assembler should generate or use a list of
  "frequent words" – also known in the |ZStandard|_ as "abbreviations" – in
  order to save space.

`<FUNNY-GLOBALS?>`:samp:

  Indicates that the compiler should simulate the ability to have more than
  240 global variables.

`<ZIP-OPTIONS {option} {option...}>`:samp:

  Indicates that the game wants to use one or more optional Z-machine
  features. The options can be `UNDO`, `COLOR`, `MOUSE`, and/or `DISPLAY`.
  This will cause the corresponding bits to be set in the game header.

`<ORDER-OBJECTS? {ordering}>`:samp:

  Changes the order in which object numbers are assigned. The ordering can be
  `ROOMS-FIRST`, `ROOMS-LAST`, or `DEFINED` (which arranges objects in source
  code order). If this directive is not used, the ordering of objects is
  undefined.

  `ROOMS-FIRST` allows room numbers to be stored in byte tables. `ROOMS-LAST`
  allows non-room object numbers to be stored in byte tables.

Global Variables
================

`<GLOBAL {name} {initial-value}>`:samp:

  Defines a global variable. The variable can then be referred to inside a
  routine as `,{name}`:samp: (the name prefixed with a comma), or changed with
  `<SETG {name} {new-value}>`:samp:.

`<CONSTANT {name} {value}>`:samp:

  Defines a global constant, which can be referred to in the same way as a
  global variable, but cannot be changed. This can be used to give a name to
  frequently used tables or strings without allocating a global variable.

Tables
======

Tables are arrays or buffers that can be located in either
`static memory`:term: or `dynamic memory`:term:.

`<ITABLE {[length-type]} {count} {[}({flags...}){]} {[default...]}>`:samp:

  Defines a table of `count`:param: elements filled with default values:
  either zeros or, if the `default`:param: list is specified, the specified
  list of values repeated until the table is full.

  The optional `length-type`:param: may be the atoms `NONE`, `BYTE`, or
  `WORD`. `BYTE` and `WORD` change the type of the table and also turn on the
  length marker, the same as giving them as `flags`:param: together with
  `LENGTH`. (For an explanation of `flags`:param:, see below.)

`<{[}P{][}L{]}TABLE {[}({flags...}){]} {values...}>`:samp:

  Defines a table containing the specified values.

  If this command is invoked as `PLTABLE`, the `PURE` and `LENGTH`
  `flags`:param: are implied; as `PTABLE`, `PURE` is implied; as `LTABLE`,
  `LENGTH` is implied; and as `TABLE`, none are implied. In all cases,
  additional `flags`:param: may be given. (For an explanation of
  `flags`:param:, see below.)

.. note::

  All of the table generating commands produce a table address, which must be
  assigned to a constant, variable, or property to be used within the game. For
  example::

    <CONSTANT MYTABLE <ITABLE BYTE 50>>

Types of Tables
---------------

These flags control the format of the table:

  * `WORD` causes the elements to be 2-byte words. This is the default.

  * `BYTE` causes the elements to be single bytes.

  * `LEXV` causes the elements to be 4-byte records.

    If default values are given to `ITABLE` with this flag, they will be split
    into groups of three: the first compiled as a word, the next two compiled
    as bytes. The table is also prefixed with a byte indicating the number of
    records, followed by a zero byte.

  * `STRING` causes the elements to be single bytes and also changes the
    initializer format. This flag may not be used with ITABLE. When this flag
    is given, any values given as strings will be compiled as a series of
    individual ASCII characters, rather than as string addresses.

Table Options
-------------

These flags alter the table without changing its basic format:

  * `LENGTH` causes a length marker to be written at the beginning of the
    table, indicating the number of elements that follow. The length marker is
    a byte if `BYTE` or `STRING` are also given; otherwise the length marker
    is a word. This flag is ignored if `LEXV` is given.

  * `PURE` causes the table to be compiled into `static memory`:term:.

Objects
=======

Objects are structures usually used to represent physical objects in the
simulated world of an IF game. There are a fixed number of objects laid out at
compile time.

Each object has a printable name, a set of boolean flags, a set of properties,
and a position within the object tree.

Object Structures
-----------------

Objects are defined with either `OBJECT` or `ROOM`. Here is a simple object
definition::

  <OBJECT CLOAK
      (DESC "cloak")
      (SYNONYM CLOAK)
      (IN PLAYER)
      (FLAGS TAKEBIT WEARBIT WORNBIT)
      (ACTION CLOAK-R)>

..

  * `CLOAK` is the symbolic name used to refer to the object in source code.

  * `DESC` defines the printable name (short description) of the object, which
    must be given as a string.

  * `SYNONYM` defines nouns that refer to the object (in this case, only the
    word "cloak"). Similarly, `ADJECTIVE` may be used to define adjectives
    that refer to the object. Both of these cause a vocabulary word to be
    compiled.

  * `IN` defines the object's location, which must be given as the name of a
    parent object (in this case, `PLAYER`). `LOC` can be used instead of `IN`.

  * `FLAGS` defines the object's initial set of flags, given as a series of
    atoms.

  * `ACTION` is a user-defined property, which in this case is being used to
    store the name of a routine to handle the object's action responses. Any
    atom other than `DESC`, `SYNONYM`, `ADJECTIVE`, `LOC`, and `FLAGS` may be
    used as a property name.

Directions
----------

Directions are properties that are linked with vocabulary words and use a
special definition syntax to define the links between rooms. Directions must
be defined at top level before any objects are defined::

  <DIRECTIONS NORTH SOUTH EAST WEST IN OUT>

Notice that `IN` may be reused as a direction name.

Each direction name will be compiled as a vocabulary word, and a direction
property may be defined on an object using the words `SORRY`, `TO`, or `PER`::

  (NORTH SORRY "A swiftly moving river blocks your path.")

Defines a non-exit. Movement in this direction is not allowed, and the player
will see a message instead.

::

  (SOUTH TO BAR)

Defines an unconditional exit. Movement in this direction leads to a specific
room.

::

  (EAST TO OUTER-SPACE IF POD-BAY-DOOR IS OPEN)

Defines a door exit dependent on a particular object. Movement in this
direction leads to a specific room, but only if the state of the object allows
it; otherwise a failure message will be shown. Optionally, a custom failure
message may be given at the end::

  (EAST TO OUTER-SPACE IF POD-BAY-DOOR IS OPEN ELSE "I can't let you do that,
  Dave.")

::

  (WEST TO VAULT IF COMBINATION-ENTERED)

Defines a conditional exit dependent on a global variable. Movement in this
direction leads to a specific room, but only if the named global variable has
a nonzero value.

As above, an optional custom failure message may be given at the end::

  (WEST TO VAULT IF COMBINATION-ENTERED ELSE "The handle won't budge.")

::

  (IN PER TELEPORTER-FCN)

Defines a conditional exit controlled by a `routine`:term:. Movement in this
direction causes the named routine to be called; it must either return a room,
or return zero and print an appropriate failure message.

Property Defaults
-----------------

Although an object's property values can change at runtime, the set of
properties defined by any particular object cannot. Writing to a property that
an object does not possess is illegal. Reading from such a property returns a
default value.

Usually, the default value of a property is zero. The default value may be
customized, though::

  <PROPDEF WEIGHT 10>

Vocabulary and Grammar
======================

Syntax Lines
------------

Parts of Speech
---------------

Routines
========

Variables
---------

Arithmetic
----------

Conditions, Branching, Looping
------------------------------

Working with Objects
--------------------

Output
------
