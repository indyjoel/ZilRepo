"use strict";

import { DebugProtocol } from "@vscode/debugprotocol";
type Message = DebugProtocol.Message;

let nextId = 100;

function msg<K extends string>(format: string): (variables: Record<K, string>) => Message {
    const id = nextId++;
    return (variables) => ({ id, format, variables });
}

/* eslint-disable @typescript-eslint/naming-convention, no-underscore-dangle, id-denylist, id-match */

export const FeatureNotImplemented =
    msg<"feature">(
        "{feature} not implemented",
    );
export const UnknownEvalContext =
    msg<"context" | "expr">(
        'Unknown eval context "{context}" for expression "{expr}"',
    );
export const Exception =
    msg<"op" | "message">(
        "Exception during {op}: {message}",
    );
