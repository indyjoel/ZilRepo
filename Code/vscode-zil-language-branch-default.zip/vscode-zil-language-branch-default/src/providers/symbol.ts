"use strict";

import {
    CancellationToken, Definition, DefinitionProvider, Disposable, DocumentSymbolProvider,
    ExtensionContext, languages, Position, ProviderResult, SymbolInformation, TextDocument, WorkspaceSymbolProvider,
} from "vscode";

import { VSCode } from "../analysis/workspace/vscode";
import { getWorkspace } from "../analysis/workspace/workspace";
import { ZIL_MODE } from "../util";

class SymbolProvider implements DocumentSymbolProvider, WorkspaceSymbolProvider, DefinitionProvider {
    public provideDocumentSymbols(
        document: TextDocument, _token: CancellationToken): ProviderResult<SymbolInformation[]> {

        return getWorkspace().getDocumentSymbols(document.uri)
            .filter((s) => s.hasDefinition())
            .map((s) => VSCode.symbolToSymbolInfo(s));
    }

    public provideWorkspaceSymbols(query: string, _token: CancellationToken): ProviderResult<SymbolInformation[]> {
        return getWorkspace().getSymbols(query)
            .filter((s) => s.hasDefinition())
            .map((s) => VSCode.symbolToSymbolInfo(s));
    }

    public provideDefinition(
        document: TextDocument, position: Position,
        _token: CancellationToken): ProviderResult<Definition> {

        // eslint-disable-next-line prefer-const
        let { word, symbols } = getWorkspace().getSymbolsAtPosition(document, position, { requireMatch: true });
        symbols = symbols.filter((s) => s.hasDefinition());

        console.log(
            `[symbols] definitions at ${position.line},${position.character}: ` +
            `word="${word.found ? word.text : ""}" ` +
            `symbols=[${symbols.map((s) => s.name).join()}]"`);

        switch (symbols.length) {
            case 0: return null;
            case 1: return symbols[0].definition;
            default: return symbols.map((s) => {
                const d = s.definition;
                if (!d) {
                    throw new Error(`Missing definition on symbol ${s.name}`);
                }
                return d;
            });
        }
    }
}

export default function registerSymbolProvider(_context: ExtensionContext): Disposable[] {
    const provider = new SymbolProvider();
    return [
        languages.registerDocumentSymbolProvider(ZIL_MODE, provider),
        languages.registerWorkspaceSymbolProvider(provider),
        languages.registerDefinitionProvider(ZIL_MODE, provider),
    ];
}
