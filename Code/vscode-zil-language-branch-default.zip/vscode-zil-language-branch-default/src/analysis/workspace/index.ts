"use strict";

// TODO: fix barrels when possible (https://github.com/Microsoft/TypeScript/issues/13245)
// export { default as Document } from "./document";
// export { default as URI } from "./uri";
// export { getWorkspace, startWorkspace, SymbolMatch, Tidbits } from "./workspace";
