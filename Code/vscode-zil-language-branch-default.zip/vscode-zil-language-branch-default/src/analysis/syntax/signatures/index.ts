"use strict";

// TODO: fix barrels when possible (https://github.com/Microsoft/TypeScript/issues/13245)
// export * from "./signature";
