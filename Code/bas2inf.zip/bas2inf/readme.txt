Bas2Inf: Basic to Inform compiler.
Written January 2007 by Johan Berntsson (johan@microheaven.com)

This code is in public domain, but it would be polite to credit my name
in any derivate work. Future development of this code is demand driven;
if you send bug reports or feature requests I will consider extending the
scope of the compiler accordingly.

1. Introduction

Bas2Inf is a compiler that translated DEC Basic code to Inform. It also
contains support for Commodore Basic V2, and can easily be extended
to cover other Basic dialects.

Bas2Inf is written in Ruby 1.8.2, and you need to install Ruby on your
computer to be able to run the compiler (bas2inf.rb).

2. Usage

The compiler is called bas2inf.rb, and is started by:
  ruby decinf.rb [switches] basic_source_file [inform_source_file]

The compiler (bas2inf.rb) takes a DEC Basic source file and creates two files:
1. the inform source file name, defaults to game.inf
2. globals.inf - contains declarations and initialisation of the basic variables

After compiling the program, the Inform source should be checked for warning
messages. It can then be compiled using the Inform compiler into binary code
that can be executed on the Z-machine.

In addition to the Basic source file, these files are used:

1. goto.txt: contains a list of line numbers that will get a label in the Inform source file
(this file is optional. The -l switch forces every line to get a label)
2. routines.inf: functions that emulate basic functions, such as MID$, TIME$ etc.
3. istring.h: a string library for the Z-machine written by L. Ross Raszewski
4. stack.h: a stack library for the Z-machine written by Fredrik Ramsberg.

More information can be displayed with "ruby bas2inf.rb -h"

3. Development

To compile Bas2Inf you need to install racc and rex (yacc and lex for ruby)

Files:
bas2inf.racc: racc grammar
bas2inf.rex: rex data file
make.bat: calls racc and rex, creates bas2inf.rb

4. How to port a basic game (instructions and example)

To port an old basic game you go through these steps

1. Get a plain text copy of the source file
2. Remove/rewrite system specific commands such as POKE, SYS,
Color control codes etc.
3. Replace I/O code for save/restore using the utility keywords
InformSaveGame and InformRestoreGame. The compiler also
understands the keywords InformSaveUndo and InformRestoreUndo,
in case you want to add undo functionality in your game.
4. Compile to Inform source, check for errors and warnings
5. Compile to a Z-machine executable.

The archive contains the source code for the C64 Basic game Sunburst.
The file sunburst.bas is the original source code, and sunburst_modified.bas
is a version that has been prepared for porting. Assuming that inform.exe is
in your search path, you can compile the game by:

ruby bas2inf.rb -l -c -v6 sunburst_modified.bas sunburst.inf

resulting in a ready-to-run sunburst.z6 executable.

Sunburst was compiled to version 6 because it handles the user input in
the basic source with GET$ and PRINT$, including deleting characters by
printing backspace. This is not possible to do in version 5 and version 8
executables. If your game never needs to write backspace characters on
the output stream, then you can compile to version 5 or version 8 instead.

5. Version history

16 Feb 2007: version 1.0 released

6. TODO

Glulx support is still very incomplete; the most serious problem is the missing
string manipulation routines. Code for StrLen, StrCpy and StrCmp is missing.
