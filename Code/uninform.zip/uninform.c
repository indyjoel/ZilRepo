/*fileit*/

#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "getopt.c"

/*
start_of_messages	=start of all messages
start_of_attribute_names    =start of all attributes names
start_of_property_names	=start of all property names
start_of_verb_names	=start of all verb names
*/

//#ifdef __STDC__
extern int getopt (int, char *[], const char *);
/*#else
extern int getopt ();
#endif*/

/* getopt linkages */

extern int optind;
extern const char *optarg;

static int option_printaddress = 0;
static int option_grammar = 1;
static int option_highobjects = 0;
static int option_lowobjects = 0;
static int option_alljumps = 0;
static int option_decimal = 0;
static int option_printhex = 0;
static int option_erase = 0;
static int option_dump = 0;
static int option_indent = 1;
static int option_width = 79;
static int option_patch = 0;

static unsigned long patch_location = 0;

long objectpos[1000],addresspos[100];
long address[100];

unsigned long startact,end_of_search=0,jumptoit,start_of_routine_marker,end_of_routine_marker,temporary_file_pointer,all_purpose_long;
int informdefined=0,brackets=0,justcred=0,lastreverse=0,afterif=0,number_of_jumps=0,dojumps=1,dontcrplease=0,no_attr_file,orphan_count=0,dont_linefeed,flag,count_loop,all_purpose_integer,screen_width=70;
char serial_number[10],common_address_buffer[10],elsestring[200],indent_string[100];

//for debugging purposes (this code, not the infocom games), set debugon=1 and compile

int nextprop=0,nextattr=0,debugon=0,inform67_defined,actionalise=0,orflag=0,verbalise=0,objectize=0,linefeed,elseflag,switchon,increase_stack_addressreturn;

//for debugging purposes, change 'debugon=0' to 'debugon=1'.

unsigned long address_of_parsing_line,spareaddress,lastroutinefound;

//address_of_parsing_line is the current address at the beginning of every line
//spareaddress is, er, something
//lastroutinefound is used by untilhexchar() and backtrack, to find the last capital 'R' and thus find the number of the hex's routine name... doesn't find 'R', just sets lastroutinefound to the location of 'R' every time it finds one.

int stack_pointer=0,opcodebytes[100];
long stored_file_position,start_of_verb_names,start_of_attribute_names,start_of_messages,start_of_property_names;
int doneelse,address_stack_pointer,maximum_objects_in_game;

//doneelse is to prevent 'else' from printing a line early...

long global_number,address_stack[100],address_stack_exchange_buffer[100];
char global_small_string[500],global_huge_string[5000],storedaddress[10],parsed_line_to_print[500],stored_parsed_line[100][300],currently_parsed_opcode[20];
int hex_bytes_to_search_for[50],linefeed_encountered;
FILE *txd_output_file, *uninform_output_file,*imported_stuff,*infodump_output_file,*attr_file;

//file 'donethat' was used in 'objectloop' and referred to the uninform_output_file when it's finished and been written to disk...

void indent_spaces();
void appendtext(FILE *,char *);
//void backtrack (FILE *,char[]);
void buildcrdefs();
void copytext(FILE *,char *);
//void getaddress(FILE *);
int put_next_word_in_string(FILE *,char[]);
int parse_input_operand(int);
int parse_output_operand(int,char[]);
//void gimmename(long,char[]);
void find_strings_from_here_and_append(long,char [],int);
void reset_commonly_used_strings();
int is_byte_hex (int);
int is_reversed ();
void load_file_position(FILE *);
unsigned long makehexa(int);
unsigned long makehexbyte(int,int);
void objectloop();
void parseeverything ();
void printobject(char [],int);
void printtext(FILE *);
void printtextcr(FILE *);
void putdefault();
void save_file_position(FILE *);
long find_string_in_file(long,FILE *,char[],int);
void strbeg(char *,char*);
int testaddress();
void underscore(char[]);
int untilhexchar(FILE *);
void increase_stack_address(int);
int getopcodebytes();
void pull_stack(char *);
void push_stack(char *);
void begin_if(int);
void getserialnumber();
unsigned long hex2dec(char *,int);

unsigned long hex2dec(char *string,int string_pos_from)
{
	unsigned long longreturn;
	int startfrom;
	startfrom=string_pos_from;
	longreturn=0L;
	if (debugon==1) fprintf(uninform_output_file,"[Hex2Dec with %s]",string);
	if (string[0]=='~') startfrom++;
	
	if (strlen(string)-startfrom==5)
	{
		longreturn=makehexa(string[startfrom]);
		longreturn*=65536;
		startfrom++;
	};
	if (strlen(string)-startfrom==3)
	{
		longreturn=makehexa(string[0]);
		longreturn*=256;
		longreturn+=makehexbyte(string[startfrom+1],string[startfrom+2]);
	};
	
	if (strlen(string)-startfrom==4)
	{
		longreturn+=makehexbyte(string[startfrom],string[startfrom+1])*256;
		longreturn+=makehexbyte(string[startfrom+2],string[startfrom+3]);
	};
	if (debugon==1) fprintf(uninform_output_file,"[Into %lx]",longreturn);
	return((unsigned long)longreturn);
};

//Start of *ALL* routines... Grepping stuff!!...

/*the purpose of getopcodebytes is to read in all the rubbishy hex data,
and read it all into an int array called opcodebytes[]. It returns the
number of opcodes it found in count_loop(). At the end, global_huge_string
contains the name of the opcode, which it gets when it doesn't get any
more hex.*/

void getserialnumber()
{
	temporary_file_pointer=find_string_in_file(0L,infodump_output_file,"Serial number:",1);
	fseek(infodump_output_file,temporary_file_pointer,SEEK_SET);
	put_next_word_in_string(infodump_output_file,serial_number);
	strbeg(serial_number,"s");
	fseek(infodump_output_file,0L,SEEK_SET);
};


void begin_if(int preference)
{
	char string[100];
	long compare1,compare2,compare3;
	if ((orflag==1)&&(justcred==0))
	{
		orflag=0;
		if (preference==0) strbeg(parsed_line_to_print,"&&(");
		if (preference==1) strbeg(parsed_line_to_print,"&&(~~");
		return;
	};
	
	if ((afterif==1)&&(justcred==0))
	{
		afterif=0;
		if (preference==0) strbeg(parsed_line_to_print,"||(");
		if (preference==1) strbeg(parsed_line_to_print,"||(~~");
		return;
	};
	/*save_file_position(txd_output_file);
	
	  while (linefeed_encountered!=1)
	  {
	  put_next_word_in_string(txd_output_file,string);
	  };
	  linefeed_encountered=0;
	  while (linefeed_encountered==0)
	  {
	  put_next_word_in_string(txd_output_file,global_huge_string);
	  };
	  
		put_next_word_in_string(txd_output_file,global_small_string);
		load_file_position(txd_output_file);
		global_small_string[strlen(global_small_string)-1]='\0';
		compare1=hex2dec(global_small_string,0);
		compare2=hex2dec(string,0);
		compare3=hex2dec(global_huge_string,0);
		global_small_string[0]='\0';
		global_huge_string[0]='\0';
		
		  linefeed_encountered=0;
		  
			if (compare1);
			if (compare2);
			if (compare3); //to prevent compiler warnings (!)
	*/
	/*if (compare3>compare1)
	{
	strbeg(parsed_line_to_print,"(");
	brackets++;
	}
	else
	if (brackets!=0)
	{
	strbeg(parsed_line_to_print,")");
	brackets--;
};*/
	
	//above commented code is some kind of check for printing brackets etc... not finished yet
	
	if (preference==0) strbeg(parsed_line_to_print,"(");
	if (preference==1) strbeg(parsed_line_to_print,"(~~");
	strbeg(parsed_line_to_print,"if ");
};


void pull_stack(char *string)
{
	strcat(string,stored_parsed_line[stack_pointer]);
	//stored_parsed_line[stack_pointer][0]='\0'; //no need erasing this, so why bother? 'test' has problem otherwise...
	stack_pointer--;
	if (stack_pointer<0)
	{
		fprintf(uninform_output_file,"![Stack underflow at %lx]\n",(unsigned long)address_of_parsing_line);
		stack_pointer=0;
	};
};

void push_stack(char *string)
{
	dont_linefeed=1;
	stack_pointer++;
	strcpy(stored_parsed_line[stack_pointer],string);
	justcred=1;
};

int getopcodebytes()
{
	int count;
	
	count_loop=0;
	put_next_word_in_string(txd_output_file,global_small_string);
	
	while ((strlen(global_small_string)==0)||(is_byte_hex(global_small_string[0]))&&(is_byte_hex(global_small_string[1]))&&(strlen(global_small_string)==2))
	{
		opcodebytes[count_loop]=makehexbyte(global_small_string[0],global_small_string[1]);
		count_loop++;
		put_next_word_in_string(txd_output_file,global_small_string);
		if ((strcmp("...",global_small_string))==0) put_next_word_in_string(txd_output_file,global_small_string);
	};
	strcpy(currently_parsed_opcode,global_small_string);
	if (option_printhex==1)
	{
		count=0;
		while (count<count_loop)
		{
			fprintf(uninform_output_file,"%02x ",opcodebytes[count]);
			count++;
		};
	};
	
	return(count_loop);
};

/*this routine simply 'sprintf's a '\n' to a string, then works out the length,
then puts the last character in the global variable 'linefeed', as this
is the last character of a linefeed character, be it 1 character, or 5
characters. Therefore, it is possible to get to the 'end of a line' on
any machine that prints a linefeed as one or more characters.*/

void buildcrdefs()
{
	char crstring[5];
	sprintf(crstring,"\n");
	linefeed=crstring[strlen(crstring)-1];
};

/*this routine gets an address and adds it to the address stack, if it is a
string such as 'rtrue' or 'rfalse' then it merely appends it and returns
(1)=rfalse (2)=rtrue. Address is in format 3,4 or 5 character hex. If there
is a tilda on the front of an address, then the hex routine considers an
extra character when turning the hex address into a number...*/

//char string[10] holds the address but this is silly...
//all_purpose_integer is used to hold the number of chars to, er, do...

int is_reversed()
{
	char string[100];
	long compare1,compare2,compare3;
	save_file_position(txd_output_file);
	
	while (linefeed_encountered!=1)
	{
		put_next_word_in_string(txd_output_file,string);
	};
	linefeed_encountered=0;
	while (linefeed_encountered==0)
	{
		put_next_word_in_string(txd_output_file,global_huge_string);
	};
	
	put_next_word_in_string(txd_output_file,global_small_string);
	load_file_position(txd_output_file);
	linefeed_encountered=0;
	
	//fprintf(uninform_output_file,"[a:%s b:%s]",global_small_string,string);
	global_small_string[strlen(global_small_string)-1]='\0';
	compare1=hex2dec(global_small_string,0);
	compare2=hex2dec(string,0);
	compare3=hex2dec(global_huge_string,0);
	
	
	//fprintf(uninform_output_file,"[1:%lx,2:%lx]",compare1,compare2);
	
	/*if ((compare1==compare3)&&(string[0]=='~')&&(lastreverse==0))
	{
	lastreverse=1;
	return(1);
	};
	
	  if ((compare1==compare3)&&(string[0]!='~')&&(lastreverse==0))
	  {
	  lastreverse=1;
	  return(0);
};*/
	
	//fprintf(uninform_output_file,"[%d %d 1:%lx 2:%lx 3:%lx]",afterif,lastreverse,compare1,compare2,compare3);
	if ((compare3!=0)&&(compare3!=compare2)&&(compare1==compare2)&&(string[0]=='~')&&(lastreverse==0))
	{
		//fprintf(uninform_output_file,"[Path1]");
		lastreverse=1;
		return(1);
	};
	
	if ((compare3!=0)&&(compare3!=compare2)&&(compare1==compare2)&&(string[0]!='~')&&(lastreverse==0))
	{
		//fprintf(uninform_output_file,"[Path1]");
		lastreverse=1;
		return(0);
	};
	//if (orbud==1) strcat(parsed_line_to_print,")");
	
	/*all_purpose_long=hex2dec(global_small_string,0);
	global_small_string[0]='\0';
	if (all_purpose_long==global_number)
	{
	orflag=1;
	dont_linefeed=1;
	return;
};*/
	
	
	if (string[0]=='~') return(0); //it's reversed.
	return(1);//it's normal...
};

void increase_stack_address(int preference)
{
	int count;
	char string[500];
	
	increase_stack_addressreturn=0;
	
	global_small_string[0]='\0';
	
	if (preference!=1)
	{
		put_next_word_in_string(txd_output_file,string);
		if ((string[1]=='r')||(string[0]=='r')) //this is not a number... it's a return
		{
			if (string[0]=='~') string[0]=' ';
			strcat(string,";");
			/*if ((string[2]=='f')||(string[1]=='f')) increase_stack_addressreturn=1;
			if (string[2]=='t')||(string[2]=='f') increase_stack_addressreturn=2;*/
			strcpy(global_small_string,string);
			return;
		}
		else
		{
			all_purpose_long=hex2dec(string,0);
			global_number=all_purpose_long;
			
			linefeed_encountered=0;
			temporary_file_pointer=ftell(txd_output_file);
			while (linefeed_encountered==0)
			{
				put_next_word_in_string(txd_output_file,global_small_string);
			};
			put_next_word_in_string(txd_output_file,string);
			string[strlen(string)-1]='\0';
			all_purpose_long=hex2dec(string,0);
			if (debugon==1) fprintf(uninform_output_file,"[Compare ifaddr:%lx twolinesaddr:%lx]",global_number,all_purpose_long);
			fseek(txd_output_file,temporary_file_pointer,SEEK_SET);
			
			if (all_purpose_long==global_number)
			{
				//firstor=1;
				afterif=1;
				dontcrplease=1;
				orflag=0;
				global_small_string[0]='\0';
				strcat(parsed_line_to_print," ");
				return;
			};
			orflag=0;
			afterif=0;
			
			all_purpose_long=hex2dec(global_small_string,0);
			global_small_string[0]='\0';
			
			if (all_purpose_long==global_number)
			{
				orflag=1;
				dont_linefeed=1;
				return;
			};
			orflag=0;
			afterif=0;
			/*if (global_number==address_stack[address_stack_pointer-1])
			{
			orflag=1;
			dont_linefeed=1;
			return; //er, this is 'or', folks...
		};*/
			
			if (global_number<address_of_parsing_line)
			{
				sprintf(string,"  jump z%lx;",global_number);
				strcat(parsed_line_to_print,string);
				return;
			};
			
			if (global_number>=address_of_parsing_line)
			{
				count_loop=0;
				
				/*while (count_loop<=address_stack_pointer)
				{
				if (global_number==address_stack[count_loop])
				{
				orflag=1;
				//return(3) //er, this is 'or', folks...
				};
				count_loop++;
			};*/
				
				address_stack[address_stack_pointer]=global_number;
				address_stack_pointer++;
				if (address_stack_pointer>=100) address_stack_pointer=100;
			};
		};
		
		strcat(parsed_line_to_print,"\n");
		count_loop=0;
		while (count_loop<address_stack_pointer)
		{
			strcat(parsed_line_to_print,indent_string);
			count_loop++;
			if (count_loop==100) break; //the array is only 100 in size
		};
		
		if (increase_stack_addressreturn==1) strcat(parsed_line_to_print,")");
		else strcat(parsed_line_to_print,"{");
		count_loop=0;
		while (count_loop<=address_stack_pointer-1)
		{
			strcat(parsed_line_to_print,indent_string);
			count_loop++;
			if (count_loop==100) break; //the array is only 100 in size
		};
};
};

//this routine is no good...

/*void backtrack(FILE *stream,char wheretostickit[10])
{
long yourcosyposition,yourlastposition;
int d,hexstringoffset;
hexstringoffset=0;

  while(d!=-2)
  {
  d=untilhexchar(imported_stuff);
  hex_bytes_to_search_for[hexstringoffset]=d;
  hexstringoffset++;
  };
  count_loop=hexstringoffset;
  hexstringoffset=0;
  fseek(txd_output_file,0L,SEEK_SET);
  
	while (hexstringoffset<count_loop-1)
	{
	d=untilhexchar(txd_output_file);
	if ((d!=hex_bytes_to_search_for[hexstringoffset])&&(hex_bytes_to_search_for[hexstringoffset]!=-1))
	{
	hexstringoffset=0;
	};
	if ((d==hex_bytes_to_search_for[hexstringoffset])||(hex_bytes_to_search_for[hexstringoffset]==-1))
	{
	hexstringoffset++;
	};
	};
	
	  fseek(stream,lastroutinefound,SEEK_SET);
	  fseek(txd_output_file,ftell(txd_output_file)+7L,SEEK_SET);
	  yourlastposition=0;
	  
		while (d!=',')
		{
		d=getc(stream);
		//printf("%c",d);
		wheretostickit[yourlastposition]=d;
		yourlastposition++;
		};
		wheretostickit[yourlastposition-1]='\0';
		};
		*/
		
		//simple... copy text from a filestream into a string until we get a '"'...
		
		void copytext(FILE *stream,char *string)
		{
			count_loop=0;
			string[count_loop]='\0'; //get rid of the ugly quotation at the end
			
			while (1)
			{
				string[count_loop]=getc(stream);
				if (string[count_loop]=='"') break;
				count_loop++;
			};
			string[count_loop]='\0'; //get rid of the ugly quotation at the end
		};
		
		//append text from a filestream to the end of a string.
		
		void appendtext(FILE *stream,char *string)
		{
			count_loop=strlen(string);
			while (1)
			{
				string[count_loop]=getc(stream);
				if (string[count_loop]=='"') break;
				count_loop++;
			};
			string[count_loop]='\0';
		};
		//chopped as it's not used!!
		/*
		void getaddress (FILE *stream)
		{
		put_next_word_in_string(stream,common_address_buffer);
		global_number=makehexbyte(common_address_buffer[0],common_address_buffer[1]);
		global_number*=1024L;
		put_next_word_in_string(stream,common_address_buffer);
		global_number=global_number+(makehexbyte(common_address_buffer[0],common_address_buffer[1])*4);
		common_address_buffer[0]='\0';
		};
		*/
		
		//this is a rather complex little routine... it takes the operands and works out what they are, then appends what they are to parsed_line_to_print...
		
		int parse_input_operand(int preferences)
		{
			char string[100];
			long temporary,tempfilepos;
			int c,quickcount;
			
			//small function below, to counteract bugs in 'put_next_word_in_string'.
			
			c=getc(txd_output_file);
			if (c==' ')
			{
				while (c==' ')
				{
					c=getc(txd_output_file);
				};
			};
			if (c=='"')
			{
				quickcount=1;
				c=0;
				string[0]='"'; //before byte... always a quote, but best to be a space
				while (c!='"')
				{
					c=getc(txd_output_file);
					if (c==' ') c='_';
					string[quickcount]=c;
					quickcount++;
				};
				string[quickcount-1]='\0';
				strcat(parsed_line_to_print,string);
				strcat(parsed_line_to_print,"\""); //put a quote on the end... but could just comment this line out for no quote (object/word comparison reasons)
				return(3);
			}
			else
			{
				fseek(txd_output_file,ftell(txd_output_file)-1L,SEEK_SET);
				if (put_next_word_in_string(txd_output_file,string)==1) linefeed_encountered=1; //99 is rather drastic; this indicates the end of a parsing line... in other words, GIVE IT UP!!
			};
			//below: if the string begins with an ' then it is a print_char, and put_next_word_in_string automatically deals with this, so it just appends it to parsed_line_to_print
			if (string[0]=='\'')
			{
				strcat(parsed_line_to_print,string);
				return(1);
			};
			
			if ((strcmp("->",string))==0)
			{
				return(99);
				//return(parse_input_operand(preferences));
			};
			
			
			//if the string begins with a " then it is obviously a string; append it to parsed_line_to_print
			if (string[0]=='"')
			{
				string[0]=' ';
				//string[strlen(string)-1]='\0';
				strcat(parsed_line_to_print,string);
				return(2);
			};
			
			//if string begins with a small 's', then it is a reference to a string. turn 's' into 'S' and use find_string_in_file() to find the string, print it.
			if ((string[0]=='s')&&(strlen(string)>=4))
			{
				string[0]='S';
				//fprintf(uninform_output_file,"\"");
				tempfilepos=ftell(txd_output_file);
				strbeg(string,": ");
				temporary=(find_string_in_file(start_of_messages,txd_output_file,string,1));
				fseek(txd_output_file,temporary+2,SEEK_SET);
				strcat(global_huge_string,"\"");
				appendtext(txd_output_file,global_huge_string);
				strcat(global_huge_string,"\"");
				fseek(txd_output_file,tempfilepos,SEEK_SET);
				strcat(parsed_line_to_print,global_huge_string);
				return(3);//this is a string, sucker!!
			};
			
			//if it begins with a '#', and then length is 5 (including '#'), then it is a 4-digit hex number... turn it into decimal, stick it in global_number
			
			if ((string[0]=='#')&&((strlen(string)==5)||(strlen(string)==6)))
			{
				all_purpose_long=hex2dec(string,1);
				global_number=all_purpose_long;
				if (((global_number<maximum_objects_in_game)&&(option_highobjects==1))||(objectize==1))
				{
					global_small_string[0]='\0';
					temporary=objectpos[global_number];
					temporary=find_string_in_file(temporary,infodump_output_file,"Description: \"",1);
					if (temporary!=-1)
					{
						fseek(infodump_output_file,temporary,SEEK_SET);
						copytext(infodump_output_file,global_small_string);
						underscore(global_small_string);
						strcat(parsed_line_to_print,global_small_string);
						return(10); //new return - this has been an object
					};
				};
				if ((preferences<2)||(preferences>=4))
				{
					if ((global_number==65535)||(global_number==32767)) sprintf(global_small_string,"NULL");//ah, the joys of a typeless language!! 65535=-1, really but my knowledge of C is not much... for some reason, "if ((signed)global_number==-1)" turned global_number into a signed number... go figure ;-)
					else
					{
						if (option_decimal==1) sprintf(global_small_string,"%ld", global_number);
						else sprintf(global_small_string,"%02x", global_number);
					};
					
					//if (actionalise==1)
					//{
					if (inform67_defined==1)
					{
						if (global_number==4096) strcpy(global_small_string,"LetGo");
						if (global_number==4097) strcpy(global_small_string,"Receive");
						if (global_number==4098) strcpy(global_small_string,"ThrownAt");
						if (global_number==4099) strcpy(global_small_string,"Order");
						if (global_number==4100) strcpy(global_small_string,"TheSame");
						if (global_number==4101) strcpy(global_small_string,"PluralFound");
						if (global_number==4102) strcpy(global_small_string,"ListMiscellany");
						if (global_number==4103) strcpy(global_small_string,"Miscellany");
						if (global_number==4104) strcpy(global_small_string,"Prompt");
						if (global_number==4105) strcpy(global_small_string,"NotUnderstood");
					};
					//if (actionalise==1) strbeg(global_small_string,"##");
					//return(4);
					//};
					strcat(parsed_line_to_print,global_small_string);
				};
				return(4);//1=this is a 4-digit hex number
			};
			
			//if string is a 2-digit hex number, convert it to decimal and bung it in global_number
			
			if ((string[0]=='#')&&(strlen(string)==3))
			{
				if (option_lowobjects==1) objectize=1;
				all_purpose_long=makehexbyte(string[1],string[2]);
				global_number=all_purpose_long;
				
				if (objectize==1) //ie, if the previous command was objectionable... this bit must go at the beginning of the routine...
				{
					if (debugon==1) fprintf(uninform_output_file,"[Objs]");
					global_small_string[0]='\0';
					temporary=objectpos[global_number];
					
					temporary=find_string_in_file(temporary,infodump_output_file,"Description: \"",1);
					
					if (temporary!=-1)
					{
						fseek(infodump_output_file,temporary,SEEK_SET);
						copytext(infodump_output_file,global_small_string);
						underscore(global_small_string);
						if (strlen(global_small_string)==0)
						{
							if (option_decimal==1) sprintf(global_small_string,"obj_%d",global_number);
							else sprintf(global_small_string,"%02x", global_number);
						};
						strcat(parsed_line_to_print,global_small_string);
						return(10); //new return - this has been an object
					};
				};
				
				if ((preferences==6)||(preferences==5)&&((objectize==0)||(verbalise==0))) //storew --> and -> storeb(and call_vs2 etc) don't want no objects when they're trying to point at things...
				{
					if (option_decimal==1) sprintf(global_small_string,"%d",global_number);
					else sprintf(global_small_string,"%02x", global_number);
					strcat(parsed_line_to_print,global_small_string);
					global_small_string[0]='\0';
					return(5);
				};
				
				if ((preferences==4)&&(inform67_defined==1)) return(5);
				
				if (verbalise==1)
				{
					global_small_string[0]='\0';
					//temporary=find_string_in_file(0L,infodump_output_file,"Action table entries",1);
					sprintf(global_small_string,"%d.",global_number);
					//printf("%d=",global_number);
					temporary=find_string_in_file(startact,infodump_output_file,global_small_string,1);
					temporary=find_string_in_file(temporary,infodump_output_file,"\"",1);
					//printtextcr(infodump_output_file);
					if (temporary!=-1)
					{
						fseek(infodump_output_file,temporary,SEEK_SET);
						copytext(infodump_output_file,global_small_string);
						//underscore(global_small_string);
						strcat(parsed_line_to_print,global_small_string);
						return(12); //new return - this has been a verbie thingy
					};
				};
				
				if (objectize==-1) objectize=1; //when we want to skip an operand and print the next one as an object
				if (actionalise==1)
				{
					if (start_of_verb_names!=-1) find_strings_from_here_and_append(start_of_verb_names,global_small_string,global_number);
					else sprintf(global_small_string,"unkrn_%lx",(unsigned long)global_number);
					strcat(parsed_line_to_print,global_small_string);
					return(3);//this has been a action thingy
				};
				
				if (nextprop>0)
				{
					if ((no_attr_file==0)&&(inform67_defined==0))
					{
						if (debugon==1) fprintf(uninform_output_file,"[Prop %d]",global_number);
						temporary=find_string_in_file(0L,attr_file,serial_number,1);
						if (temporary!=-1) //have we found the definitions for this serial number?
						{
							end_of_search=find_string_in_file(temporary,attr_file,"[end]",1);
							sprintf(global_small_string,"property %d ",global_number);
							temporary=find_string_in_file(temporary,attr_file,global_small_string,1);
							fseek(attr_file,temporary,SEEK_SET);
							sprintf(global_small_string,"%d",global_number);
							end_of_search=0;
							
							if (temporary!=-1) //has the property definition been found?
							{
								put_next_word_in_string(attr_file,global_small_string);
								strcat(parsed_line_to_print,global_small_string);
								if (debugon==1) fprintf(uninform_output_file,"[Succ %s]",global_small_string);
								put_next_word_in_string(attr_file,global_small_string);
								
								if (global_small_string[0]=='o')
								{
									objectize=1;
								};
								
								if (global_small_string[0]=='n')
								{
									objectize=0;
								};
								
								if (global_small_string[0]=='p')
								{
									objectize=-1;
								};
								global_small_string[0]='\0';
								return(6);
								//return(15); //new return - this has been a property thingie
							};
						};
					};
					//strcat(parsed_line_to_print,global_small_string);
					nextprop--;
				};
				
				if (nextattr>0)
				{
					if ((no_attr_file==0)&&(inform67_defined==0))
					{
						if (debugon==1) fprintf(uninform_output_file,"[Attr %d]",global_number);
						temporary=find_string_in_file(0L,attr_file,serial_number,1);
						if (temporary!=-1) //have we found the definitions for this serial number?
						{
							end_of_search=find_string_in_file(temporary,attr_file,"[end]",1);
							sprintf(global_small_string,"attribute %d ",global_number);
							temporary=find_string_in_file(temporary,attr_file,global_small_string,1);
							fseek(attr_file,temporary,SEEK_SET);
							end_of_search=0;
							
							if (temporary!=-1) //has the attribute definition been found?
							{
								put_next_word_in_string(attr_file,global_small_string);
								strcat(parsed_line_to_print,global_small_string);
								global_small_string[0]='\0';
								return(13); //new return - this has been an attribute thingie
							};
						};
					};
					//sprintf(global_small_string,"%d",global_number);
					nextattr--;
					//strcat(parsed_line_to_print,global_small_string);
				};
				
				if ((preferences==0)||(preferences==4))
				{
					if (option_decimal==1) sprintf(global_small_string,"%d",global_number);
					else sprintf(global_small_string,"%02x", global_number);
					strcat(parsed_line_to_print,global_small_string);
					global_small_string[0]='\0';
					return(5);//standard 2-digit number
				};
				
				global_small_string[0]='\0';
				return(5);//2=this is a 2-digit hex number
};

//the string must be a z-machine-code address. just stick it in storedaddress

/*if ((is_byte_hex(string[1]))&&(is_byte_hex(string[2]))&&(is_byte_hex(string[3])))
{
strcpy(storedaddress,string);
return(6);//4=this is an hex XXX or XXXX or XXXXX-style address
};*/

//if string is a global variable, attempt a guess at its' name.

if ((string[0]=='g')&&(strlen(string)==3))
{
	
	if (((strcmp("ge9",string))==0)&&(inform67_defined==1))
	{
		switchon=0;
		strcpy(parsed_line_to_print,"\n\t![**_______]\n\t    ");
		actionalise=1;
		return(7);//this is a action... nothing copied...
	};
	
	/*if ((strcmp("g2c",string))==0)
	{
	save_file_position(txd_output_file);
	all_purpose_long=parse_input_operand(2);
	strcat(parsed_line_to_print,"second");
	global_small_string[0]='\0';
	sfprintf(uninform_output_file,global_small_string,"%d. Attributes:",all_purpose_long);
	temporary=find_string_in_file(0L,infodump_output_file,global_small_string,1);
	temporary=find_string_in_file(temporary,infodump_output_file,"Description: \"",1);
	
	  if (temporary!=-1)
	  {
	  fseek(infodump_output_file,temporary,SEEK_SET);
	  copytext(infodump_output_file,global_small_string);
	  strcat(parsed_line_to_print,global_small_string);
	  load_file_position(txd_output_file);
	  return(10); //new return - this has been an object
	  };
	  };
	*/
	all_purpose_long=makehexbyte(string[1],string[2]);
	global_number=all_purpose_long;
	c=linefeed_encountered;
	
	if ((no_attr_file==0)&&(inform67_defined==0))
	{
		if (debugon==1) fprintf(uninform_output_file,"[Glob %x]",global_number);
		//all_purpose_long=temporary;
		//mark here for changes
		//objectize=1;
		temporary=find_string_in_file(0L,attr_file,serial_number,1);
		if (temporary!=-1) //have we found the definitions for this serial number?
		{
			end_of_search=find_string_in_file(temporary,attr_file,"[end]",1);
			sprintf(global_small_string,"global %02x ",global_number);
			temporary=find_string_in_file(temporary,attr_file,global_small_string,1);
			fseek(attr_file,temporary,SEEK_SET);
			put_next_word_in_string(attr_file,global_small_string);
			end_of_search=0;
			if (debugon==1) fprintf(uninform_output_file,"[Globbed %s]",global_small_string);
			if (temporary!=-1) //has the global var definition been found?
			{
				strcat(parsed_line_to_print,global_small_string);
				put_next_word_in_string(attr_file,global_small_string);
				all_purpose_integer=linefeed_encountered;
				if (global_small_string[0]=='a')
				{
					verbalise=1;
				};
				
				if (global_small_string[0]=='o')
				{
					objectize=1;
				};
				if (global_small_string[0]=='n')
				{
					objectize=0;
				};
				if (global_small_string[0]=='p') //pause 1 object before printing
				{
					objectize=-1;
				};
				linefeed_encountered=c;
				return(14); //new return - this has been a global thingie
			};
		};
		//temporary=all_purpose_long;
	};
	
	//the following snipped routine goes through verblibm.h looking for global names - can't be bothered yet
	
	/*if ((global_number<100)&&(global_number>0))
	{
	global_small_string[0]='\0';
	temporary=find_string_in_file(0L,globals,"Global ",global_number);
	put_next_word_in_string(globals,global_small_string);
	strcat(parsed_line_to_print,global_small_string);
	//copytext(globals,parsed_line_to_print);
	//};
	return(5);
}; */
	
	//some common library 6/7 globals: (these need to be assimilated first...)
	
	//this is a mess at present...
	
	/*if ((strcmp("gef",string))==0)
	{
	if (switchon==0) strcat(parsed_line_to_print,string);
	return(11); //this has been a switch reference
};*/
/*
if ((strcmp("geb",string))==0) strcpy(string,"self");

  if ((strcmp("g00",string))==0)
  {
  strcpy(string,"location");
  objectize=1;
};*/
	
/*if ((strcmp("gb8",string))==0)
{
strcpy(string,"noun");
objectize=1;
};

  if ((strcmp("gb9",string))==0)
  {
  strcpy(string,"second");
  objectize=1;
  };
  
	if ((strcmp("gba",string))==0)
	{
	strcpy(string,"verb");
	verbalise=1;
};*/
	//if ((strcmp("g16",string))==0) strcpy(string,"player");
	linefeed_encountered=c;
	sprintf(string,"g%02x",global_number);
	strcat(parsed_line_to_print,string);
	return(8);
};

//if the string is 'sp', then it refers to stack pointer, therefore, print what *would* be in the stack pointer...

if ((strcmp("sp",string))==0)
{
	if ((preferences>4)&&(linefeed_encountered==1)) printf("");
	else
	{
		//if (stack_pointer>1) strbeg(parsed_line_to_print,"(");
		pull_stack(parsed_line_to_print);
		//if (stack_pointer>1) strcat(parsed_line_to_print,")");
	};
	return(9);
};

//failing all the above, just stick the string on the end and pray that it's okay...

strcat(parsed_line_to_print,string);
return(0);//all's well...
};

int put_next_word_in_string(FILE *stream, char wheretoputitalso[100])
{
	int c,inchars,spaceend,nextwordreturn;
	spaceend=0;
	inchars=0;
	nextwordreturn=0;
	if ((ftell(stream)>start_of_messages)&&(start_of_messages>5))
	{
		fclose(txd_output_file);
		fclose(infodump_output_file);
		fclose(uninform_output_file);
		printf("Hmm... tried reading file past Z-code stuff... exiting...\n");
		exit(0);
	}; // a mere precaution routine... not implemented... if program gets in an infinite loop, put this in and it will exit safely... However, shouldn't get in an infinite loop
	
	while ((c=getc(stream))!=EOF)
	{
		if ((c==13)&&(linefeed!=13)) continue;
		if (c==linefeed)
		{
			linefeed_encountered=1;
			nextwordreturn=1;
		};
		
		if (c=='\'')
		{
			wheretoputitalso[inchars]='\'';
			c=getc(stream);
			wheretoputitalso[inchars+1]=c;
			c=getc(stream);
			wheretoputitalso[inchars+2]=c;
			wheretoputitalso[inchars+3]='\0';
			return(1);
		};
		
		if (((c==linefeed)&&(spaceend==0))||((c==' ')&&(spaceend==0))) continue;
		else spaceend=1;
		
		if (c==linefeed) linefeed_encountered=1;
		if (((c==' ')&&(spaceend==1))||(c==linefeed))
		{
			if (c!=linefeed) wheretoputitalso[inchars]=c;
			break;
		};
		if ((c!='?')&&(c!=10))
		{
			wheretoputitalso[inchars]=c;
			inchars++;
		};
	};
	wheretoputitalso[inchars]='\0';
	return(nextwordreturn);
};

int parse_output_operand(int wheretoappend,char appendit[50]) //1=beginning 0=end
{
	char string[100];
	long temporary;
	
	put_next_word_in_string(txd_output_file,string);
	
	if ((strcmp("->",string))==0)
	{
		return(parse_output_operand(wheretoappend,appendit));
	};
	
	if ((string[0]=='g')&&(strlen(string)==3))
	{
		all_purpose_long=makehexbyte(string[1],string[2]);
		global_number=all_purpose_long;
		
		if ((no_attr_file==0)&&(inform67_defined==0))
		{
			if (debugon==1) fprintf(uninform_output_file,"[Glob %x]",global_number);
			temporary=find_string_in_file(0L,attr_file,serial_number,1);
			if (temporary!=-1) //have we found the definitions for this serial number?
			{
				end_of_search=find_string_in_file(temporary,attr_file,"[end]",1);
				temporary=find_string_in_file(temporary,attr_file,"globals",1);
				sprintf(global_small_string,"g%02x ",global_number);
				temporary=find_string_in_file(temporary,attr_file,global_small_string,1);
				fseek(attr_file,temporary,SEEK_SET);
				put_next_word_in_string(attr_file,global_small_string);
				end_of_search=0;
				if (debugon==1) fprintf(uninform_output_file,"[Globbed %s]",global_small_string);
				if (temporary!=-1) //has the global var definition been found?
				{
					if (wheretoappend&1)
					{
						strbeg(parsed_line_to_print,appendit);
						strbeg(parsed_line_to_print,global_small_string);
						return(0);
					};
					if (wheretoappend&1==0)
					{
						strcat(parsed_line_to_print,global_small_string);
						strcat(parsed_line_to_print,appendit);
						return(0);
					};
					put_next_word_in_string(attr_file,global_small_string);
					all_purpose_integer=linefeed_encountered;
					/*if (global_small_string[0]=='a')
					{
					verbalise=1;
					};
					
					  if (global_small_string[0]=='o')
					  {
					  objectize=1;
					  };
					  if (global_small_string[0]=='n')
					  {
					  objectize=0;
					  };
					  if (global_small_string[0]=='p') //pause 1 object before printing
					  {
					  objectize=-1;
				};*/
					linefeed_encountered=all_purpose_integer;
				};
			};
		};
		sprintf(string,"g%02x",global_number);
		if (wheretoappend&1)
		{
			strbeg(parsed_line_to_print,appendit);
			strbeg(parsed_line_to_print,string);
		};
		if (wheretoappend&1==0)
		{
			strcat(parsed_line_to_print,string);
			strcat(parsed_line_to_print,appendit);
		};
		return(0);
	};
	
	if ((strcmp("sp",string))==0)
	{
		if ((wheretoappend>1)&&(informdefined==0))
		{
			save_file_position(txd_output_file);
			linefeed_encountered=0;
			while ((strcmp("->",string))!=0)
			{
				put_next_word_in_string(txd_output_file,string);
				if (ftell(txd_output_file)>end_of_routine_marker) break;
				if (((strcmp("ret_popped",string))==0)
					||((strcmp("pop",string))==0)||((strcmp("pull",string))==0)||((strcmp("pop_stack",string))==0)||((strcmp("sp",string)==0)))
				{
					load_file_position(txd_output_file);
					push_stack(parsed_line_to_print);
					return(1);
				};
			};
			//push_stack(parsed_line_to_print);
			linefeed_encountered=0;
			load_file_position(txd_output_file);
			return(0);
		};
		push_stack(parsed_line_to_print);
		return(1);
	};
	
	if (wheretoappend&1)
	{
		strbeg(parsed_line_to_print,appendit);
		strbeg(parsed_line_to_print,string);
	};
	if (wheretoappend&1==0)
	{
		strcat(parsed_line_to_print,string);
		strcat(parsed_line_to_print,appendit);
	};
	return(0);
};

//The function gimmename: as obsolete as a ZX81.

/*void gimmename(long wheretoguvnor,char string[20])
{
long tempfilepos,moretemp;
int hexbyte;

  if (string[0]=='#')
  {
  hexbyte=makehexbyte(string[1],string[2]);
  moretemp=ftell(txd_output_file);
  tempfilepos=find_string_in_file(wheretoguvnor,txd_output_file," \"",hexbyte+1);
  fseek(txd_output_file,tempfilepos,SEEK_SET);
  copytext(txd_output_file,string);
  fseek(txd_output_file,moretemp,SEEK_SET);
  }
  };
  */
  
  /*find_strings_from_here_and_append? More like: Append the text howmany strings after the file
  position stored in wheretoguvnor to the specified string.*/
  
  void find_strings_from_here_and_append(long wheretoguvnor,char string[200],int howmany)
  {
	  long moretemp;
	  
	  if (wheretoguvnor<0)
	  {
		  return;
	  };
	  moretemp=ftell(txd_output_file);
	  
	  temporary_file_pointer=find_string_in_file(wheretoguvnor,txd_output_file," \"",howmany+1);
	  if (temporary_file_pointer==-1) return;
	  fseek(txd_output_file,temporary_file_pointer,SEEK_SET);
	  copytext(txd_output_file,string);
	  fseek(txd_output_file,moretemp,SEEK_SET);
  };
  
  void reset_commonly_used_strings()
  {
	  parsed_line_to_print[0]='\0';
	  global_huge_string[0]='\0';
	  global_small_string[0]='\0';
	  linefeed_encountered=0;
  };
  
  int is_byte_hex (int e)
  {
	  if (((e>='a')&&(e<='f'))||((e>='0')&&(e<='9'))) return(1);
	  else return(0);
  };
  
  void load_file_position (FILE *stream)
  {
	  fseek(stream,stored_file_position,SEEK_SET);
  };
  
  unsigned long makehexbyte (int hexa,int hexb)
  {
	  int myhex;
	  
	  myhex=0;
	  
	  if ((hexa>='a') && (hexa<='f'))
	  {
		  myhex=myhex+(hexa-'a'+10)*16;
	  }
	  else
	  {
		  myhex=myhex+(hexa-'0')*16;
	  };
	  
	  if ((hexb>='a') &&(hexb<='f'))
	  {
		  myhex=myhex+(hexb-'a'+10);
	  }
	  else
	  {
		  myhex=myhex+(hexb-'0');
	  };
	  return(myhex);
  };
  
  unsigned long makehexa (int hexa)
  {
	  int myhex;
	  
	  myhex=0;
	  if ((hexa>='a') && (hexa<='f'))
	  {
		  myhex=myhex+(hexa-'a'+10);
	  }
	  else
	  {
		  myhex=myhex+(hexa-'0');
	  };
	  return(myhex);
  };
  
  /*void objectloop()
  {
  char string[200];
  long anothertemp,moretemp,temporary,endofattr,hereattr;
  int c;
  temporary=0;
  reset_commonly_used_strings();
  while (temporary!=-1)
  {
  temporary=find_string_in_file(temporary,infodump_output_file,"Attributes:",1);
  hereattr=temporary;
  fseek(infodump_output_file,temporary,SEEK_SET);
  c=0;
  while (1)
  {
  fprintf(uninform_output_file,"\n");
  indent_spaces();
  c=put_next_word_in_string(infodump_output_file,string);
  if (string[0]=='N') parsed_line_to_print[0]='\0';
  if (string[0]=='N') break;
  if (c==0) string[strlen(string)-1]='\0';
  global_number=atoi(string);
  find_strings_from_here_and_append(start_of_attribute_names,string,global_number);
  strcat(parsed_line_to_print,string);
  strcat(parsed_line_to_print," ");
  if (c==1) break;
  };
  temporary=find_string_in_file(temporary,infodump_output_file,"Description: \"",1);
  endofattr=find_string_in_file(temporary,infodump_output_file,"Attributes: \"",1)-18;
  fseek(infodump_output_file,temporary,SEEK_SET);
  global_small_string[0]='\0';
  copytext(infodump_output_file,global_small_string);
  
	if (parsed_line_to_print[0]!='\0')
	{
	strcat(parsed_line_to_print,",");
	strbeg(parsed_line_to_print," has ");
	};
	strcpy(string,global_small_string);
	underscore(string);
	
	  strbeg(parsed_line_to_print,"\"");
	  strbeg(parsed_line_to_print,global_small_string);
	  strbeg(parsed_line_to_print,"\"");
	  strbeg(parsed_line_to_print,string);
	  
		fprintf(uninform_output_file,"%s",parsed_line_to_print);
		
		  temporary=find_string_in_file(ftell(infodump_output_file),infodump_output_file,". ",0)-4;
		  
			while (1)
			{
			hereattr=find_string_in_file(hereattr,infodump_output_file,"[",1);
			if (hereattr>temporary) fseek(infodump_output_file,temporary,SEEK_SET);
			if (hereattr>temporary) break;
			
			  fseek(infodump_output_file,hereattr,SEEK_SET);
			  put_next_word_in_string(infodump_output_file,string);
			  string[strlen(string)-1]='\0';
			  global_number=atoi(string);
			  find_strings_from_here_and_append(start_of_property_names,string,global_number);
			  
				if (global_number==1) strcpy(string,"name");
				if (global_number==2) strcpy(string,"Class");
				
				  fprintf(uninform_output_file,"\n");
				  indent_spaces();
				  fprintf(uninform_output_file,"%s ",string);
				  linefeed_encountered=0;
				  while (linefeed_encountered!=1)
				  {
				  //getaddress(infodump_output_file);
				  if (((strcmp("number",string))==0)||((strcmp("capacity",string))==0))
				  {
				  fprintf(uninform_output_file,"%ld",global_number);
				  break;
				  };
				  
					if (((global_number/4)<400)&&(global_number>0))
					{printobject(parsed_line_to_print,global_number/4);
					fprintf(uninform_output_file,"%s;",parsed_line_to_print);
					reset_commonly_used_strings();
					}
					else
					{
					sprintf(global_small_string,"%lx",global_number);
					endofattr=find_string_in_file(0L,donethat,global_small_string,1);
					if (endofattr==-1) break;
					
					  fseek(donethat,endofattr,SEEK_SET);
					  c=getc(donethat);
					  if (c==':')
					  {
					  c=getc(txd_output_file);
					  if (c==' ')
					  {
					  c=getc(donethat);
					  
						if (c=='S')
						{
						put_next_word_in_string(txd_output_file,string);
						fprintf(uninform_output_file,"\"");
						c=getc(txd_output_file);
						printtext(txd_output_file);
						fprintf(uninform_output_file,"\"");
						};
						};
						}
						else
						{
						sprintf(global_small_string,"[ %lx ",global_number);
						endofattr=find_string_in_file(0L,donethat,global_small_string,1);
						if (endofattr==-1) break;
						
						  fseek(donethat,endofattr,SEEK_SET);
						  
							while (1)
							{
							c=getc(donethat);
							fprintf(uninform_output_file,"%c",c);
							save_file_position(donethat);
							if (c==']')
							{
							break;
							}
							else load_file_position(donethat);
							};
							};
							};
							global_number=0;
							if (linefeed_encountered) break;
							};
							if (ftell(infodump_output_file)>=temporary) break;
							};
							reset_commonly_used_strings();
							fprintf(uninform_output_file,"\n");
							indent_spaces();
							};
							exit(0);
							};
*/
void parseeverything()
{
	int noflag,c,d,e,startfrom;
	long temporary,tempfilepos,moretemp,hexstringoffset,hexbyte;
	char firstopcode[5],thisaddress[10],routinename[20];
	stored_parsed_line[0][0]='\0';
	stack_pointer=0;
	
	while (ftell(txd_output_file)<start_of_messages)
	{
		put_next_word_in_string(txd_output_file,global_small_string);
		
		if (global_small_string[strlen(global_small_string)-1]==':')
		{
			global_small_string[strlen(global_small_string)-1]='\0';
			all_purpose_long=hex2dec(global_small_string,0);
			address_of_parsing_line=(unsigned long)all_purpose_long;
			
			//if (inform67_defined==0)
			
			count_loop=0;
			while (count_loop<number_of_jumps)
			{
				
				if ((address_of_parsing_line==address[count_loop])&&((addresspos[count_loop]>ftell(txd_output_file))||(addresspos[count_loop]==-1)))
				{
					fprintf(uninform_output_file,".z%lx;\n",address_of_parsing_line);
					indent_spaces();
					break;
				};
				count_loop++;
			};
			
			/*if (dojumps==1)
			{
			temporary_file_pointer=ftell(txd_output_file);
			end_of_search=end_of_routine_marker;
			
			  while (1)
			  {
			  sprintf(global_small_string,"%lx",(unsigned long)address_of_parsing_line);
			  jumptoit=find_string_in_file(ftell(txd_output_file),txd_output_file,global_small_string,1);
			  if (jumptoit==-1) break;
			  fseek(txd_output_file,jumptoit-(long)strlen(global_small_string),SEEK_SET);
			  put_next_word_in_string(txd_output_file,global_small_string);
			  all_purpose_long=hex2dec(global_small_string,0);
			  if (all_purpose_long==address_of_parsing_line)
			  {
			  fprintf(uninform_output_file,".z%lx;\n",address_of_parsing_line);
			  indent_spaces();
			  fseek(txd_output_file,temporary_file_pointer,SEEK_SET);
			  };
			  if (all_purpose_long==address_of_parsing_line) break;
			  };
			  fseek(txd_output_file,temporary_file_pointer,SEEK_SET);
			  end_of_search=0;
		};*/
			//printf(".%lx",address_of_parsing_line);
			getopcodebytes();
			if (debugon==1) fprintf(uninform_output_file,"\n![PC:%lx] [Loop SP:%d] [String SP:%d=\"%s\"] [OC:\"%s\"]\n",(unsigned long)address_of_parsing_line,address_stack_pointer,stack_pointer,stored_parsed_line[stack_pointer],currently_parsed_opcode);
			if (option_printaddress==1) fprintf(uninform_output_file,".z%lx; ",(unsigned long)address_of_parsing_line);
			/********************beginning of annoying routine************/
			if ((address_of_parsing_line!=0)&&(doneelse==0))
			{
				count_loop=0;
				
				while (count_loop!=address_stack_pointer)
				{
					if (address_stack_pointer==0) break;
					if (address_of_parsing_line==address_stack[count_loop])
					{
						address_stack_pointer--;
						fprintf(uninform_output_file,"}\n");
						indent_spaces();
						address_stack[count_loop]=0;
						c=1;
						//if (count_loop>address_stack_pointer)
						break;
					};
					count_loop++;
				};
				if (c==1)
				{
					address_of_parsing_line=0;
					count_loop=0;
					d=0;
					while (count_loop<address_stack_pointer)
					{
						if (address_stack[count_loop]!=0)
						{
							address_stack_exchange_buffer[d]=address_stack[count_loop];
							d++;
						};
						count_loop++;
					};
					count_loop=0;
					while (count_loop<=d)
					{
						address_stack[d]=address_stack_exchange_buffer[d];
						count_loop++;
					};
					address_stack_pointer=d;
				};
			}
			else doneelse=0;
			/************************the end of annoying routine***********/
			
			//or else...
			
			/*if (elseflag==1)
			{
			indent_spaces();
			fprintf(uninform_output_file,"%s\n",elsestring);
			indent_spaces();
			elseflag=0;
			continue;
};*/
			
			
			//reset some common variables...
			
			actionalise=0;
			verbalise=0;
			nextattr=0;
			nextprop=0;
			dont_linefeed=0;
			
			if ((strcmp("jump",currently_parsed_opcode))==0)
			{
				//dont_linefeed=1;
				//dontcrplease=1;
				reset_commonly_used_strings();
				//save_file_position(txd_output_file);
				put_next_word_in_string(txd_output_file,global_small_string);
				all_purpose_long=hex2dec(global_small_string,0);
				if (all_purpose_long<address_of_parsing_line)
				{
					fprintf(uninform_output_file,"jump z%s;",global_small_string);
				}
				else
				{
					if (option_alljumps==1)
					{
						count_loop=0;
						while (count_loop<=number_of_jumps)
						{
							if (address[count_loop]==all_purpose_long) addresspos[count_loop]=-1;
							count_loop++;
						};
						fprintf(uninform_output_file,"jump z%s;",global_small_string);
					}
					else continue;
				};
				/*if (informdefined==0)
				{
				load_file_position(txd_output_file);
				increase_stack_address(0);
				fprintf(uninform_output_file,"[yo]%s",parsed_line_to_print);*/
				
				//dont_linefeed=0;
				//continue;
				
				//};
				//else dont_linefeed=1;
				//increase_stack_address(0);
				//strcpy(elsestring,parsed_line_to_print);
				//elseflag=1;
				/*
				{
				startfrom=0;
				if (strlen(global_small_string)==5)
				{
				all_purpose_long=makehexa(global_small_string[startfrom])*65536;
				startfrom++;
				};
				
				  all_purpose_long+=makehexbyte(global_small_string[startfrom],global_small_string[startfrom+1])*256;
				  all_purpose_long+=makehexbyte(global_small_string[startfrom+2],global_small_string[startfrom+3]);
				  address_of_parsing_line=(unsigned long)all_purpose_long;
				  printf("Here:%lx Jump%:lx\n",all_purpose_long,jumptoit);
				  if (all_purpose_long==jumptoit) printf("jump .farjump");
				  if (switchon==0)
				  {
				  elseflag=1;
				  };
				continue;*/
				currently_parsed_opcode[0]='\0';
			};
			
			if ((strcmp("je",currently_parsed_opcode))==0)
			{
				reset_commonly_used_strings();
				begin_if(0);
				d=parse_input_operand(0);
				if (d!=7)
				{
					e=is_reversed();
					if (e==1) strcat(parsed_line_to_print,"~=");
					else strcat(parsed_line_to_print,"==");
				};
				flag=0;
				while (linefeed_encountered==0)
				{
					temporary_file_pointer=ftell(txd_output_file);
					c=strlen(parsed_line_to_print);
					if ((flag==1)&&(linefeed_encountered==0))
					{
						if (d!=7) strcat(parsed_line_to_print," or ");
						else strcat(parsed_line_to_print,", ");
					};
					parse_input_operand(0); //5 means 'if linefeed, don't push the stack'
					if (flag==0) c=strlen(parsed_line_to_print);
					flag=1;
				};
				
				fseek(txd_output_file,temporary_file_pointer,SEEK_SET);
				parsed_line_to_print[c]='\0';
				
				if (d!=7) strcat(parsed_line_to_print,")");
				else
				{
					strcat(parsed_line_to_print,":");
					c=1;
				};
				increase_stack_address(0);
				fprintf(uninform_output_file,"%s",parsed_line_to_print);
				fprintf(uninform_output_file,"%s",global_small_string);
				currently_parsed_opcode[0]='\0';
				if (c==1)
				{
					afterif=0;
					orflag=0;
				};
			};
			
			if (((strcmp("call_vs2",currently_parsed_opcode))==0)||((strcmp("call_vs",currently_parsed_opcode))==0)||((strcmp("call",currently_parsed_opcode))==0))
			{
				reset_commonly_used_strings();
				c=testaddress();
				
				//fprintf(uninform_output_file,"vs__(1)%d (2)%d",opcodebytes[0],opcodebytes[1]);
				c=0;
				flag=0;
				while (c!=99)
				{
					if (flag!=0) strcat(parsed_line_to_print,",");
					c=parse_input_operand(0);
					flag++;
				};
				if (flag!=1) parsed_line_to_print[strlen(parsed_line_to_print)-1]=')';
				else strcat(parsed_line_to_print,")");
				
				if (parse_output_operand(3,"=")==0)
				{
					strcat(parsed_line_to_print,";");
					fprintf(uninform_output_file,"%s",parsed_line_to_print);
				}
				//else strcat(stored_parsed_line[stack_pointer],")");
				
				currently_parsed_opcode[0]='\0';
			};
			
			if (((strcmp("call_vn2",currently_parsed_opcode))==0)||((strcmp("call_vn",currently_parsed_opcode))==0))
			{
				reset_commonly_used_strings();
				c=testaddress();
				
				//fprintf(uninform_output_file,"vs__(1)%d (2)%d",opcodebytes[0],opcodebytes[1]);
				
				flag=0;
				while (linefeed_encountered==0)
				{
					if ((flag==1)&&(linefeed_encountered==0)) strcat(parsed_line_to_print,",");
					parse_input_operand(0);
					flag=1;
				};
				strcat(parsed_line_to_print,");");
				fprintf(uninform_output_file,"%s",parsed_line_to_print);
				currently_parsed_opcode[0]='\0';
			};
			
			if ((strcmp("call_1s",currently_parsed_opcode))==0)
			{
				reset_commonly_used_strings();
				c=testaddress();
				//should call testaddress with parameter '2' in future
				strcat(parsed_line_to_print,")");
				
				if (parse_output_operand(3,"=")==0)
				{
					strcat(parsed_line_to_print,";");
					fprintf(uninform_output_file,"%s",parsed_line_to_print);
				};
				
				currently_parsed_opcode[0]='\0';
			};
			
			if ((strcmp("call_2s",currently_parsed_opcode))==0)
			{
				reset_commonly_used_strings();
				c=testaddress();
				//should call testaddress with parameter '2' in future
				parse_input_operand(0);
				strcat(parsed_line_to_print,")");
				
				if (parse_output_operand(3,"=")==0)
				{
					strcat(parsed_line_to_print,";");
					fprintf(uninform_output_file,"%s",parsed_line_to_print);
				};
				
				currently_parsed_opcode[0]='\0';
			};
			
			if ((strcmp("call_2n",currently_parsed_opcode))==0)
			{
				reset_commonly_used_strings();
				c=testaddress();
				//should call testaddress with parameter '2' in future
				parse_input_operand(0);
				strcat(parsed_line_to_print,")");
				strcat(parsed_line_to_print,";");
				fprintf(uninform_output_file,"%s",parsed_line_to_print);
				currently_parsed_opcode[0]='\0';
			};
			
			if ((strcmp("call_1n",currently_parsed_opcode))==0)
			{
				reset_commonly_used_strings();
				c=testaddress();
				//should call testaddress with parameter '2' in future
				strcat(parsed_line_to_print,")");
				strcat(parsed_line_to_print,";");
				fprintf(uninform_output_file,"%s",parsed_line_to_print);
				currently_parsed_opcode[0]='\0';
			};
			
			if ((strcmp("split_window",currently_parsed_opcode))==0)
			{
				reset_commonly_used_strings();
				strcat(parsed_line_to_print,"@split_window ");
				parse_input_operand(0);
				fprintf(uninform_output_file,"%s;",parsed_line_to_print);
				currently_parsed_opcode[0]='\0';
			};
			
			if ((strcmp("read_char",currently_parsed_opcode))==0)
			{
				reset_commonly_used_strings();
				strcat(parsed_line_to_print,"@set_window ");
				while (parse_input_operand(0)!=99);
				if (parse_output_operand(1,"=")==0)
				{
					strcat(parsed_line_to_print,";");
					fprintf(uninform_output_file,"%s",parsed_line_to_print);
				};
			};
			
			
			if ((strcmp("set_window",currently_parsed_opcode))==0)
			{
				reset_commonly_used_strings();
				strcat(parsed_line_to_print,"@set_window ");
				parse_input_operand(0);
				fprintf(uninform_output_file,"%s;",parsed_line_to_print);
				currently_parsed_opcode[0]='\0';
			};
			
			if ((strcmp("buffer_mode",currently_parsed_opcode))==0)
			{
				reset_commonly_used_strings();
				strcat(parsed_line_to_print,"@buffer_mode ");
				parse_input_operand(0);
				fprintf(uninform_output_file,"%s;",parsed_line_to_print);
				currently_parsed_opcode[0]='\0';
			};
			
			if ((strcmp("set_cursor",currently_parsed_opcode))==0)
			{
				reset_commonly_used_strings();
				strcat(parsed_line_to_print,"@set_cursor ");
				while (linefeed_encountered==0)
				{
					parse_input_operand(0);
					strcat(parsed_line_to_print," ");
				};
				fprintf(uninform_output_file,"%s;",parsed_line_to_print);
				currently_parsed_opcode[0]='\0';
			};
			
			if ((strcmp("scan_table",currently_parsed_opcode))==0)
			{
				reset_commonly_used_strings();
				begin_if(0);
				fprintf(uninform_output_file,"%s",parsed_line_to_print);
				parsed_line_to_print[0]='\0';
				strcat(parsed_line_to_print,"(@scan_table ");
				parse_input_operand(0);
				strcat(parsed_line_to_print,",");
				parse_input_operand(0);
				strcat(parsed_line_to_print,",");
				parse_input_operand(0);
				strcat(parsed_line_to_print,")");
				
				parse_output_operand(1,"=");
				
				//if (parse_output_operand(1,"=")==0)
				//{
				strcat(parsed_line_to_print,")");
				fprintf(uninform_output_file,"%s",parsed_line_to_print);
				//};
				parsed_line_to_print[0]='\0';
				increase_stack_address(0);
				fprintf(uninform_output_file,"%s",parsed_line_to_print);
				fprintf(uninform_output_file,"%s",global_small_string);
				currently_parsed_opcode[0]='\0';
			};
			
			if ((strcmp("dec",currently_parsed_opcode))==0)
			{
				reset_commonly_used_strings();
				parse_input_operand(0);
				strcat(parsed_line_to_print,"--;");
				fprintf(uninform_output_file,"%s",parsed_line_to_print);
				currently_parsed_opcode[0]='\0';
			};
			
			if ((strcmp("mod",currently_parsed_opcode))==0)
			{
				reset_commonly_used_strings();
				parse_input_operand(0);
				strcat(parsed_line_to_print,"%");
				parse_input_operand(0);
				
				if (parse_output_operand(1,"=")==0)
				{
					strcat(parsed_line_to_print,";");
					fprintf(uninform_output_file,"%s",parsed_line_to_print);
				};
				currently_parsed_opcode[0]='\0';
			};
			
			if ((strcmp("ret_popped",currently_parsed_opcode))==0)
			{
				reset_commonly_used_strings();
				strcat(parsed_line_to_print,"return (");
				pull_stack(parsed_line_to_print);
				//stored_parsed_line[0][0]='\0';
				fprintf(uninform_output_file,"%s);",parsed_line_to_print);
				currently_parsed_opcode[0]='\0';
			};
			
			if ((strcmp("push",currently_parsed_opcode))==0)
			{
				reset_commonly_used_strings();
				parse_input_operand(0);
				push_stack(parsed_line_to_print);
				//strcpy(stored_parsed_line[0],parsed_line_to_print);
				currently_parsed_opcode[0]='\0';
				//stored_parsed_line[0][0]='\0';
			};
			
			if ((strcmp("pull",currently_parsed_opcode))==0)
			{
				reset_commonly_used_strings();
				parse_input_operand(0);
				strcat(parsed_line_to_print,"=");
				pull_stack(parsed_line_to_print);
				//strcat(parsed_line_to_print,stored_parsed_line[0]);
				fprintf(uninform_output_file,"%s;",parsed_line_to_print);
				currently_parsed_opcode[0]='\0';
				//stored_parsed_line[0][0]='\0';
			};
			
			if ((strcmp("pop",currently_parsed_opcode))==0)
			{
				reset_commonly_used_strings();
				pull_stack(parsed_line_to_print);
				currently_parsed_opcode[0]='\0';
				currently_parsed_opcode[0]='\0';
			};
			
			if ((strcmp("pop_stack",currently_parsed_opcode))==0)
			{
				reset_commonly_used_strings();
				parse_input_operand(0);
				stack_pointer-=global_number;
				currently_parsed_opcode[0]='\0';
				currently_parsed_opcode[0]='\0';
			};
			
			if ((strcmp("storew",currently_parsed_opcode))==0)
			{
				reset_commonly_used_strings();
				strcat(parsed_line_to_print,"(");
				parse_input_operand(0);
				strcat(parsed_line_to_print,"-->");
				parse_input_operand(6);
				strcat(parsed_line_to_print,")=");
				parse_input_operand(0);
				fprintf(uninform_output_file,"%s;",parsed_line_to_print);
				currently_parsed_opcode[0]='\0';
			};
			
			if ((strcmp("storeb",currently_parsed_opcode))==0)
			{
				reset_commonly_used_strings();
				strcat(parsed_line_to_print,"(");
				parse_input_operand(0);
				strcat(parsed_line_to_print,"->");
				parse_input_operand(6);
				strcat(parsed_line_to_print,")=");
				parse_input_operand(0);
				fprintf(uninform_output_file,"%s;",parsed_line_to_print);
				currently_parsed_opcode[0]='\0';
			};
			if ((strcmp("loadw",currently_parsed_opcode))==0)
			{
				reset_commonly_used_strings();
				strcat(parsed_line_to_print,"(");
				parse_input_operand(0);
				strcat(parsed_line_to_print,"-->");
				parse_input_operand(6);
				strcat(parsed_line_to_print,")");
				
				if (parse_output_operand(1,"=")==0)
				{
					strcat(parsed_line_to_print,";");
					fprintf(uninform_output_file,"%s",parsed_line_to_print);
				};
				currently_parsed_opcode[0]='\0';
			};
			
			if ((strcmp("loadb",currently_parsed_opcode))==0)
			{
				reset_commonly_used_strings();
				strcat(parsed_line_to_print,"(");
				parse_input_operand(0);
				strcat(parsed_line_to_print,"->");
				parse_input_operand(6);
				strcat(parsed_line_to_print,")");
				
				if (parse_output_operand(1,"=")==0)
				{
					strcat(parsed_line_to_print,";");
					fprintf(uninform_output_file,"%s",parsed_line_to_print);
				};
				currently_parsed_opcode[0]='\0';
			};
			
			if ((strcmp("div",currently_parsed_opcode))==0)
			{
				reset_commonly_used_strings();
				parse_input_operand(0);
				strcat(parsed_line_to_print,"/");
				parse_input_operand(0);
				
				if (parse_output_operand(1,"=")==0)
				{
					strcat(parsed_line_to_print,";");
					fprintf(uninform_output_file,"%s",parsed_line_to_print);
				};
				currently_parsed_opcode[0]='\0';
			};
			
			if ((strcmp("get_prop_len",currently_parsed_opcode))==0)
			{
				reset_commonly_used_strings();
				strcat(parsed_line_to_print,"@get_prop_len(");
				parse_input_operand(0);
				strcat(parsed_line_to_print,")");
				
				if (parse_output_operand(1,"=")==0)
				{
					strcat(parsed_line_to_print,";");
					fprintf(uninform_output_file,"%s",parsed_line_to_print);
				};
				currently_parsed_opcode[0]='\0';
			};
			
			if ((strcmp("dec_chk",currently_parsed_opcode))==0)
			{
				reset_commonly_used_strings();
				begin_if(0);
				//strcat(parsed_line_to_print,"(");
				parse_input_operand(0);
				strcat(parsed_line_to_print,"--==");
				parse_input_operand(0);
				strcat(parsed_line_to_print,")");
				increase_stack_address(0);
				fprintf(uninform_output_file,"%s",parsed_line_to_print);
				fprintf(uninform_output_file,"%s",global_small_string);
				currently_parsed_opcode[0]='\0';
			};
			
			if ((strcmp("inc_chk",currently_parsed_opcode))==0)
			{
				reset_commonly_used_strings();
				begin_if(0);
				//strcat(parsed_line_to_print,"(");
				parse_input_operand(0);
				strcat(parsed_line_to_print,"++==");
				parse_input_operand(0);
				strcat(parsed_line_to_print,")");
				increase_stack_address(0);
				fprintf(uninform_output_file,"%s",parsed_line_to_print);
				fprintf(uninform_output_file,"%s",global_small_string);
				currently_parsed_opcode[0]='\0';
			};
			
			
			
			if ((strcmp("mul",currently_parsed_opcode))==0)
			{
				reset_commonly_used_strings();
				parse_input_operand(0);
				strcat(parsed_line_to_print,"*");
				parse_input_operand(0);
				
				if (parse_output_operand(1,"=")==0)
				{
					strcat(parsed_line_to_print,";");
					fprintf(uninform_output_file,"%s",parsed_line_to_print);
				};
				currently_parsed_opcode[0]='\0';
			};
			
			if ((strcmp("inc",currently_parsed_opcode))==0)
			{
				reset_commonly_used_strings();
				parse_input_operand(0);
				strcat(parsed_line_to_print,"++;");
				fprintf(uninform_output_file,"%s",parsed_line_to_print);
				currently_parsed_opcode[0]='\0';
			};
			
			if ((strcmp("get_parent",currently_parsed_opcode))==0)
			{
				reset_commonly_used_strings();
				strcpy(parsed_line_to_print,"parent (");
				parse_input_operand(0);
				strcat(parsed_line_to_print,")");
				if (parse_output_operand(1,"=")==0) fprintf(uninform_output_file,"%s;",parsed_line_to_print);
				currently_parsed_opcode[0]='\0';
			};
			
			if ((strcmp("store",currently_parsed_opcode))==0)
			{
				reset_commonly_used_strings();
				c=parse_input_operand(0);
				if (c==11)
				{
					strcpy(parsed_line_to_print,"Switch("); //this is a switch
					switchon=1;
				}
				else strcat(parsed_line_to_print,"=");
				parse_input_operand(0);
				if (c==11) strcat(parsed_line_to_print,")");
				fprintf(uninform_output_file,"%s",parsed_line_to_print);
				if (c!=11) fprintf(uninform_output_file,";");
				currently_parsed_opcode[0]='\0';
			};
			
			if ((strcmp("sub",currently_parsed_opcode))==0)
			{
				reset_commonly_used_strings();
				parse_input_operand(0);
				strcat(parsed_line_to_print,"-");
				c=parse_input_operand(0);
				if (parse_output_operand(1,"=")==0) fprintf(uninform_output_file,"%s;",parsed_line_to_print);
				currently_parsed_opcode[0]='\0';
			};
			
			if ((strcmp("get_prop",currently_parsed_opcode))==0)
			{
				reset_commonly_used_strings();
				parse_input_operand(0);
				strcat(parsed_line_to_print,".");
				c=parse_input_operand(1);
				
				if ((inform67_defined==1)&&(c==5))
				{
					find_strings_from_here_and_append(start_of_property_names,global_small_string,global_number);
					strcat(parsed_line_to_print,global_small_string);
				};
				if ((c==5)&&(inform67_defined==0))
				{
					sprintf(global_small_string,"%d",global_number);
					strcat(parsed_line_to_print,global_small_string);
				};
				
				if (parse_output_operand(1,"=")==0) fprintf(uninform_output_file,"%s;",parsed_line_to_print);
				currently_parsed_opcode[0]='\0';
			};
			
			if ((strcmp("add",currently_parsed_opcode))==0)
			{
				reset_commonly_used_strings();
				parse_input_operand(0);
				
				strcat(parsed_line_to_print,"+");
				c=parse_input_operand(0);
				
				if (parse_output_operand(1,"=")==0) fprintf(uninform_output_file,"%s;",parsed_line_to_print);
				currently_parsed_opcode[0]='\0';
			};
			
			if ((strcmp("or",currently_parsed_opcode))==0)
			{
				reset_commonly_used_strings();
				parse_input_operand(0);
				
				strcat(parsed_line_to_print,"|");
				c=parse_input_operand(0);
				
				if (parse_output_operand(1,"=")==0) fprintf(uninform_output_file,"%s;",parsed_line_to_print);
				currently_parsed_opcode[0]='\0';
			};
			
			if ((strcmp("not",currently_parsed_opcode))==0)
			{
				reset_commonly_used_strings();
				strcat(parsed_line_to_print,"~");
				parse_input_operand(0);
				
				if (parse_output_operand(1,"=")==0) fprintf(uninform_output_file,"%s;",parsed_line_to_print);
				currently_parsed_opcode[0]='\0';
			};
			
			
			if ((strcmp("get_child",currently_parsed_opcode))==0)
			{
				reset_commonly_used_strings();
				strcpy(parsed_line_to_print,"child(");
				parse_input_operand(0);
				strcat(parsed_line_to_print,")");
				if (parse_output_operand(1,"=")==0)
				{
					fprintf(uninform_output_file,"%s;",parsed_line_to_print);
				};
				currently_parsed_opcode[0]='\0';
			};
			
			if ((strcmp("get_sibling",currently_parsed_opcode))==0)
			{
				reset_commonly_used_strings();
				strcpy(parsed_line_to_print,"sibling(");
				parse_input_operand(0);
				strcat(parsed_line_to_print,")");
				if (parse_output_operand(1,"=")==0)
				{
					fprintf(uninform_output_file,"%s;",parsed_line_to_print);
				};
				currently_parsed_opcode[0]='\0';
			};
			
			if ((strcmp("and",currently_parsed_opcode))==0)
			{
				reset_commonly_used_strings();
				strcat(parsed_line_to_print,"(");
				parse_input_operand(0);
				strcat(parsed_line_to_print,"&");
				parse_input_operand(0);
				strcat(parsed_line_to_print,")");
				if (parse_output_operand(1,"=")==0) fprintf(uninform_output_file,"%s;",parsed_line_to_print);
				currently_parsed_opcode[0]='\0';
			};
			
			if ((strcmp("test",currently_parsed_opcode))==0)
			{
				reset_commonly_used_strings();
				begin_if(0);
				parse_input_operand(0);
				d=stack_pointer;
				strcat(parsed_line_to_print,"&");
				temporary_file_pointer=ftell(txd_output_file);
				parse_input_operand(0);
				
				fseek(txd_output_file,temporary_file_pointer,SEEK_SET);
				strcat(parsed_line_to_print,")==(");
				stack_pointer=d;
				parse_input_operand(0);
				strcat(parsed_line_to_print,")");
				global_small_string[0]='\0';
				increase_stack_address(0);
				fprintf(uninform_output_file,"%s",parsed_line_to_print);
				fprintf(uninform_output_file," %s",global_small_string);
				currently_parsed_opcode[0]='\0';
			};
			
			if ((strcmp("remove_obj",currently_parsed_opcode))==0)
			{
				reset_commonly_used_strings();
				fprintf(uninform_output_file,"remove ");
				objectize=1;
				parse_input_operand(0);
				fprintf(uninform_output_file,"%s;",parsed_line_to_print);
				currently_parsed_opcode[0]='\0';
			};
			
			if ((strcmp("set_text_style",currently_parsed_opcode))==0)
			{
				fprintf(uninform_output_file,"style ");
				put_next_word_in_string(txd_output_file,global_small_string);
				if ((strcmp("boldface",global_small_string))==0) strcpy(global_small_string,"bold");
				
				fprintf(uninform_output_file,"%s;",global_small_string);
				currently_parsed_opcode[0]='\0';
			};
			
			if ((strcmp("insert_obj",currently_parsed_opcode))==0)
			{
				reset_commonly_used_strings();
				strcpy(parsed_line_to_print,"move ");
				objectize=1;
				parse_input_operand(0);
				strcat(parsed_line_to_print," to ");
				parse_input_operand(0);
				fprintf(uninform_output_file,"%s;",parsed_line_to_print);
				currently_parsed_opcode[0]='\0';
			};
			
			/*if ((strcmp("je",currently_parsed_opcode))==0)
			{
			reset_commonly_used_strings();
			
			  if ((opcodebytes[0]==65)||(opcodebytes[0]==97)||((opcodebytes[0]==193)&&(opcodebytes[1]==143)))
			  {
			  c=parse_input_operand(0);
			  if ((c==11)&&(switchon==1)) // is this a switch check?
			  {
			  strcat(parsed_line_to_print,"\t");
			  parse_input_operand(0);
			  strcat(parsed_line_to_print,":");
			  }
			  else
			  
				if (c==7)
				{
				strcat(parsed_line_to_print,":");
				put_next_word_in_string(txd_output_file,global_small_string);
				}
				else
				{
				begin_if(0);
				//strbeg(parsed_line_to_print,"if (");
				strcat(parsed_line_to_print,"==");
				parse_input_operand(0);
				strcat(parsed_line_to_print,")");
				};
				increase_stack_address(0);
				fprintf(uninform_output_file,"%s",parsed_line_to_print);
				};
				
				  if (opcodebytes[0]==193)
				  {
				  if ((opcodebytes[1]==151))//||(opcodebytes[1]==131))
				  {
				  c=parse_input_operand(0);
				  if (c==7)
				  {
				  put_next_word_in_string(txd_output_file,global_small_string);
				  strcat(parsed_line_to_print,", ");
				  all_purpose_long=parse_input_operand(1);
				  save_file_position(txd_output_file);
				  if (all_purpose_long==5) find_strings_from_here_and_append(start_of_verb_names,global_small_string,global_number);
				  strcat(parsed_line_to_print,global_small_string);
				  strcat(parsed_line_to_print,":");
				  load_file_position(txd_output_file);
				  }
				  else
				  {
				  //strbeg(parsed_line_to_print,"if (");
				  begin_if(0);
				  strcat(parsed_line_to_print,"==");
				  parse_input_operand(0);
				  strcat(parsed_line_to_print," || ");
				  parse_input_operand(0);
				  strcat(parsed_line_to_print,")");
				  };
				  increase_stack_address(0);
				  fprintf(uninform_output_file,"%s",parsed_line_to_print);
				  };
				  
					
					  if ((opcodebytes[1]==149)||(opcodebytes[1]==128)||(opcodebytes[1]==133))
					  {
					  c=parse_input_operand(0);
					  if (c==7)
					  {
					  put_next_word_in_string(txd_output_file,global_small_string);
					  strcat(parsed_line_to_print,", ");
					  all_purpose_long=parse_input_operand(1);
					  save_file_position(txd_output_file);
					  if (all_purpose_long==5) find_strings_from_here_and_append(start_of_verb_names,global_small_string,global_number);
					  strcat(parsed_line_to_print,global_small_string);
					  strcat(parsed_line_to_print,", ");
					  load_file_position(txd_output_file);
					  all_purpose_long=parse_input_operand(1);
					  save_file_position(txd_output_file);
					  if (all_purpose_long==5) find_strings_from_here_and_append(start_of_verb_names,global_small_string,global_number);
					  strcat(parsed_line_to_print,global_small_string);
					  strcat(parsed_line_to_print,":");
					  load_file_position(txd_output_file);
					  }
					  else
					  {
					  //strbeg(parsed_line_to_print,"if (");
					  begin_if(0);
					  strcat(parsed_line_to_print,"==");
					  parse_input_operand(0);
					  strcat(parsed_line_to_print," || ");
					  parse_input_operand(0);
					  strcat(parsed_line_to_print," || ");
					  parse_input_operand(0);
					  strcat(parsed_line_to_print,")");
					  };
					  
						increase_stack_address(0);
						fprintf(uninform_output_file,"%s",parsed_line_to_print);
						};
						};
						
						  currently_parsed_opcode[0]='\0';
						  };
*/

if ((strcmp("jl",currently_parsed_opcode))==0)
{
	reset_commonly_used_strings();
	//fprintf(uninform_output_file,"if (");
	begin_if(0);
	fprintf(uninform_output_file,"%s",parsed_line_to_print);
	parsed_line_to_print[0]='\0';
	parse_input_operand(0);
	strcat(parsed_line_to_print,".");
	e=strlen(parsed_line_to_print);
	parse_input_operand(0);
	
	d=is_reversed();
	
	if (d==0)
	{
		if (parsed_line_to_print[e]=='.') parsed_line_to_print[e]='<';
		if (parsed_line_to_print[e-1]=='.') parsed_line_to_print[e-1]='<';
	}
	else
	{
		if (parsed_line_to_print[e]=='.') parsed_line_to_print[e]='>';
		if (parsed_line_to_print[e-1]=='.') parsed_line_to_print[e-1]='>';
	};
	strcat(parsed_line_to_print,")");
	increase_stack_address(0);
	fprintf(uninform_output_file,"%s",parsed_line_to_print);
	//fprintf(uninform_output_file,"%s",global_small_string);
	currently_parsed_opcode[0]='\0';
};
if ((strcmp("jg",currently_parsed_opcode))==0)
{
	reset_commonly_used_strings();
	//fprintf(uninform_output_file,"if (");
	begin_if(0);
	fprintf(uninform_output_file,"%s",parsed_line_to_print);
	parsed_line_to_print[0]='\0';
	parse_input_operand(0);
	strcat(parsed_line_to_print,".");
	e=strlen(parsed_line_to_print);
	parse_input_operand(0);
	
	d=is_reversed();
	
	if (d==0)
	{
		if (parsed_line_to_print[e]=='.') parsed_line_to_print[e]='>';
		if (parsed_line_to_print[e-1]=='.') parsed_line_to_print[e-1]='>';
	}
	else
	{
		if (parsed_line_to_print[e]=='.') parsed_line_to_print[e]='<';
		if (parsed_line_to_print[e-1]=='.') parsed_line_to_print[e-1]='<';
	};
	strcat(parsed_line_to_print,")");
	increase_stack_address(0);
	fprintf(uninform_output_file,"%s",parsed_line_to_print);
	//fprintf(uninform_output_file,"%s",global_small_string);
	currently_parsed_opcode[0]='\0';
};

if((strcmp("jz",currently_parsed_opcode))==0)
{
	reset_commonly_used_strings();
	parse_input_operand(0);
	/*save_file_position(txd_output_file);
	put_next_word_in_string(txd_output_file,storedaddress);
	load_file_position(txd_output_file);
	strcat(parsed_line_to_print,")");
	*/
	d=is_reversed();
	strcat(parsed_line_to_print,")");
	increase_stack_address(0);
	
	all_purpose_integer=orflag;
	orflag=0;
	
	if (increase_stack_addressreturn==1) begin_if(1);//strbeg(parsed_line_to_print,"if (~~");
	if (increase_stack_addressreturn==2) begin_if(0);//strbeg(parsed_line_to_print,"if (");
	if (increase_stack_addressreturn==0)
	{
		if (d==0) begin_if(1);
		else begin_if(0);
	};
	orflag=all_purpose_integer;
	fprintf(uninform_output_file,"%s",parsed_line_to_print);
	fprintf(uninform_output_file," %s",global_small_string);
	
	currently_parsed_opcode[0]='\0';
};

if ((strcmp("print_obj",currently_parsed_opcode))==0)
{
	reset_commonly_used_strings();
	strcat(parsed_line_to_print,"print (name) ");
	parse_input_operand(0);
	fprintf(uninform_output_file,"%s;",parsed_line_to_print);
	currently_parsed_opcode[0]='\0';
};

if ((strcmp("test_attr",currently_parsed_opcode))==0)
{
	reset_commonly_used_strings();
	//strcat(parsed_line_to_print,"if (");
	begin_if(0);
	objectize=1;
	parse_input_operand(0);
	objectize=0;
	save_file_position(txd_output_file);
	put_next_word_in_string(txd_output_file,global_small_string);
	put_next_word_in_string(txd_output_file,storedaddress);
	if (storedaddress[0]=='~') strcat(parsed_line_to_print," has ");
	else strcat(parsed_line_to_print," hasnt ");
	load_file_position(txd_output_file);
	
	nextattr=1;
	
	if ((parse_input_operand(4)==5)&&(inform67_defined==1))
	{
		find_strings_from_here_and_append(start_of_attribute_names,global_small_string,global_number);
		strcat(parsed_line_to_print,global_small_string);
	};
	
	strcat(parsed_line_to_print,")");
	increase_stack_address(0);
	fprintf(uninform_output_file,"%s",parsed_line_to_print);
	fprintf(uninform_output_file,"%s",global_small_string);
	currently_parsed_opcode[0]='\0';
};

if ((strcmp("put_prop",currently_parsed_opcode))==0)
{
	reset_commonly_used_strings();
	parse_input_operand(0);
	strcat(parsed_line_to_print,".");
	nextprop=1;
	c=parse_input_operand(1);
	
	if ((inform67_defined==1)&&(c==5))
	{
		find_strings_from_here_and_append(start_of_property_names,global_small_string,global_number);
		strcat(parsed_line_to_print,global_small_string);
	};
	
	if ((c==5)&&(inform67_defined==0))
	{
		sprintf(global_small_string,"%d",global_number);
		strcat(parsed_line_to_print,global_small_string);
	};
	
	strcat(parsed_line_to_print,"=");
	c=parse_input_operand(0);
	fprintf(uninform_output_file,"%s",parsed_line_to_print);
	//if (c==3) fprintf(uninform_output_file,"%s",global_huge_string);
	fprintf(uninform_output_file,";");
	currently_parsed_opcode[0]='\0';
};

if ((strcmp("random",currently_parsed_opcode))==0)
{
	reset_commonly_used_strings();
	strcat(parsed_line_to_print,"random (");
	parse_input_operand(0);
	strcat(parsed_line_to_print,")");
	
	if (parse_output_operand(1,"=")==0)
	{
		strcat(parsed_line_to_print,";");
		fprintf(uninform_output_file,"%s",parsed_line_to_print);
	};
	currently_parsed_opcode[0]='\0';
};


if ((strcmp("print_addr",currently_parsed_opcode))==0)
{
	reset_commonly_used_strings();
	strcat(parsed_line_to_print,"print (name) ");
	parse_input_operand(0);
	fprintf(uninform_output_file,"%s;",parsed_line_to_print);
	currently_parsed_opcode[0]='\0';
};

//if ((strcmp("get_prop_len",currently_parsed_opcode))==0)


if ((strcmp("get_prop_addr",currently_parsed_opcode))==0)
{
	reset_commonly_used_strings();
	parse_input_operand(0);
	strcat(parsed_line_to_print,".&");
	c=parse_input_operand(1);
	if ((c==5)&&(inform67_defined==1))
	{
		find_strings_from_here_and_append(start_of_property_names,global_small_string,global_number);
		strcat(parsed_line_to_print,global_small_string);
	};
	if (c!=5)
	{
		sprintf(global_small_string,"%d",global_number);
		strcat(parsed_line_to_print,global_small_string);
	};
	
	if (parse_output_operand(1,"=")==0)
	{
		strcat(parsed_line_to_print,";");
		fprintf(uninform_output_file,"%s",parsed_line_to_print);
	};
	currently_parsed_opcode[0]='\0';
};

if ((strcmp("set_attr",currently_parsed_opcode))==0)
{
	reset_commonly_used_strings();
	strcpy(parsed_line_to_print,"give ");
	objectize=1;
	parse_input_operand(0);
	objectize=0;
	strcat(parsed_line_to_print," ");
	nextattr=1;
	c=parse_input_operand(4);
	if ((c==5)&&(inform67_defined==1))
	{
		find_strings_from_here_and_append(start_of_attribute_names,global_small_string,global_number);
		strcat(parsed_line_to_print,global_small_string);
	};
	strcat(parsed_line_to_print,";");
	fprintf(uninform_output_file,"%s",parsed_line_to_print);
	currently_parsed_opcode[0]='\0';
};

if ((strcmp("clear_attr",currently_parsed_opcode))==0)
{
	reset_commonly_used_strings();
	strcpy(parsed_line_to_print,"give ");
	objectize=1;
	parse_input_operand(0);
	objectize=0;
	strcat(parsed_line_to_print," ~");
	nextattr=1;
	c=parse_input_operand(4);
	if ((c==5)&&(inform67_defined==1))
	{
		find_strings_from_here_and_append(start_of_attribute_names,global_small_string,global_number);
		strcat(parsed_line_to_print,global_small_string);
	};
	strcat(parsed_line_to_print,";");
	fprintf(uninform_output_file,"%s",parsed_line_to_print);
	currently_parsed_opcode[0]='\0';
};

if ((strcmp("new_line",currently_parsed_opcode))==0)
{
	fprintf(uninform_output_file,"new_line;");
	currently_parsed_opcode[0]='\0';
};

if ((strcmp("print",currently_parsed_opcode))==0)
{
	linefeed_encountered=0;
	temporary_file_pointer=ftell(txd_output_file);
	while (linefeed_encountered==0)
	{
		put_next_word_in_string(txd_output_file,global_small_string);
	};
	put_next_word_in_string(txd_output_file,global_small_string);
	getopcodebytes();
	if (debugon==1) fprintf(uninform_output_file,"[ParseAheadPrint1:%s]",global_small_string);
	
	if ((strcmp("new_line",global_small_string))==0)
	{
		linefeed_encountered=0;
		while (linefeed_encountered==0)
		{
			put_next_word_in_string(txd_output_file,global_small_string);
		};
		put_next_word_in_string(txd_output_file,global_small_string);
		getopcodebytes();
		if (debugon==1) fprintf(uninform_output_file,"[ParseAheadPrint2:%s]",global_small_string);
		if ((strcmp("rtrue",global_small_string))==0)
		{
			all_purpose_long=ftell(txd_output_file);
		}
		else
		{
			fprintf(uninform_output_file,"print ");
			all_purpose_long=-1;
		};
	}
	else
	{
		fprintf(uninform_output_file,"print ");
		all_purpose_long=-1;
	};
	
	fseek(txd_output_file,temporary_file_pointer,SEEK_SET);
	
	c=' ';
	while (c==' ') c=getc(txd_output_file);
	
	fprintf(uninform_output_file,"\"");
	printtext(txd_output_file);
	fprintf(uninform_output_file,"\";");
	if (all_purpose_long!=-1) fseek(txd_output_file,all_purpose_long,SEEK_SET);
	currently_parsed_opcode[0]='\0';
};

if ((strcmp("jin",currently_parsed_opcode))==0)
{
	reset_commonly_used_strings();
	//strcat(parsed_line_to_print,"if (");
	begin_if(0);
	e=is_reversed();
	parse_input_operand(0);
	
	if (e==1) strcat(parsed_line_to_print," notin ");
	else strcat(parsed_line_to_print," in ");
	
	parse_input_operand(0);
	strcat(parsed_line_to_print,")");
	increase_stack_address(0);
	fprintf(uninform_output_file,"%s",parsed_line_to_print);
	fprintf(uninform_output_file,"%s",global_small_string);
	currently_parsed_opcode[0]='\0';
};

if ((strcmp("print_ret",currently_parsed_opcode))==0)
{
	c=' ';
	while (c==' ') c=getc(txd_output_file);
	fprintf(uninform_output_file,"\"");
	printtext(txd_output_file);
	fprintf(uninform_output_file,"\";");
	currently_parsed_opcode[0]='\0';
};

if ((strcmp("ret",currently_parsed_opcode))==0)
{
	reset_commonly_used_strings();
	strcpy(parsed_line_to_print,"return ");
	//objectize==1 to print objects... don't put any other code in here...
	c=parse_input_operand(0); //should be (1)
	fprintf(uninform_output_file,"%s;",parsed_line_to_print);
	currently_parsed_opcode[0]='\0';
};

if ((strcmp("rtrue",currently_parsed_opcode))==0)
{
	fprintf(uninform_output_file,"rtrue;");
	currently_parsed_opcode[0]='\0';
};

if ((strcmp("rfalse",currently_parsed_opcode))==0)
{
	fprintf(uninform_output_file,"rfalse;");
	currently_parsed_opcode[0]='\0';
};

if ((strcmp("print_char",currently_parsed_opcode))==0)
{
	reset_commonly_used_strings();
	strcat(parsed_line_to_print,"print (char) ");
	parse_input_operand(0);
	fprintf(uninform_output_file,"%s;",parsed_line_to_print);
	currently_parsed_opcode[0]='\0';
};

if ((strcmp("print_paddr",currently_parsed_opcode))==0)
{
	reset_commonly_used_strings();
	c=parse_input_operand(0);
	all_purpose_long=-1;
	/*
	if ((c==3)&&(inform67_defined==1))
	{
	temporary_file_pointer=ftell(txd_output_file);
	put_next_word_in_string(txd_output_file,global_small_string);
	getopcodebytes();
	if (debugon==1) fprintf(uninform_output_file,"[ParseAheadPrint1:%s]",global_small_string);
	if ((strcmp("new_line",global_small_string))==0)
	{
	linefeed_encountered=0;
	while (linefeed_encountered==0)
	{
	put_next_word_in_string(txd_output_file,global_small_string);
	};
	put_next_word_in_string(txd_output_file,global_small_string);
	getopcodebytes();
	if (debugon==1) fprintf(uninform_output_file,"[ParseAheadPrint2:%s]",global_small_string);
	fseek(txd_output_file,all_purpose_long,SEEK_SET);
	if ((strcmp("rtrue",global_small_string))==0)
	{
	all_purpose_long=ftell(txd_output_file);
	}
	else
	{
	fprintf(uninform_output_file,"print ");
	all_purpose_long=-1;
	};
	}
	else
	{
	all_purpose_long=-1;
	};
	
	  fseek(txd_output_file,temporary_file_pointer,SEEK_SET);
};    */
	
	//if (c==3) fprintf(uninform_output_file,"%s;",global_huge_string);
	//else if (all_purpose_long==-1)
	
	//disregard above commented-out code... needs work... next line is temporary
	
	if(c==3) fprintf(uninform_output_file,"print %s;",parsed_line_to_print);
	else
		
		fprintf(uninform_output_file,"print (string) %s;",parsed_line_to_print);
	currently_parsed_opcode[0]='\0';
};

if ((strcmp("print_num",currently_parsed_opcode))==0)
{
	reset_commonly_used_strings();
	
	strcat(parsed_line_to_print,"print ");
	parse_input_operand(0);
	fprintf(uninform_output_file,"%s;",parsed_line_to_print);
	currently_parsed_opcode[0]='\0';
};

if (currently_parsed_opcode[0]!='\0')
{
	if (currently_parsed_opcode[0]=='"') fprintf(uninform_output_file,"!");
	fprintf(uninform_output_file,"@%s ",currently_parsed_opcode);
	printtextcr(txd_output_file);
	fprintf(uninform_output_file,";");
};
justcred=0;
if ((dont_linefeed==0)&&(dontcrplease==0))
{
	orflag=0;
	afterif=0;
	lastreverse=0;
	justcred=1;
	count_loop=0;
	
	fprintf(uninform_output_file,"\n");
};
dontcrplease=0;
indent_spaces();
objectize=0;
verbalise=0;
};

//bodged it here... ever heard of 'Parsing routine?'... this means it's a hotch...

if ((strcmp("orphan",global_small_string))==0)
{
	fprintf(uninform_output_file,"];\n!orphan code\n[rn_orphan%d;\n",orphan_count);
	orphan_count++;
	linefeed_encountered=0;
	stack_pointer=0;
	address_stack_pointer=0;
	
	while (linefeed_encountered==0)
	{
		put_next_word_in_string(txd_output_file,global_small_string);
	};
};


if (((strcmp("Routine",global_small_string))==0)||((strcmp("Main",global_small_string))==0))

//((global_small_string[0]=='R')&&(global_small_string[1]=='o'))
{
	orflag=0;
	afterif=0;
	lastreverse=1;
	brackets=0;
	temporary_file_pointer=ftell(txd_output_file);
	sprintf(global_huge_string,"%cRoutine ",linefeed);
	if (dojumps==1) end_of_routine_marker=find_string_in_file(ftell(txd_output_file),txd_output_file,global_huge_string,1);
	
	if (end_of_routine_marker==-1) find_string_in_file(ftell(txd_output_file),txd_output_file,"[End of code",1);
	fseek(txd_output_file,temporary_file_pointer,SEEK_SET);
	count_loop=0;
	while ((ftell(txd_output_file)<end_of_routine_marker)&&(end_of_routine_marker!=-1))
	{
		linefeed_encountered=0;
		while (linefeed_encountered!=1)
		{
			put_next_word_in_string(txd_output_file,global_huge_string);
		};
		
		if ((strlen(global_huge_string)>=3)&&(global_huge_string[0]!='"'))
		{
			e=0;
			if (global_huge_string[0]=='~') e=1;
			
			d=0;
			c=0; //indicates 1=no success... string is not hex
			while (d<strlen(global_huge_string))
			{
				if (is_byte_hex(global_huge_string[d+e])==0) c=1;
				d++;
			};
			
			if (c==0)
			{
				address[count_loop]=hex2dec(global_huge_string,0);
				addresspos[count_loop]=ftell(txd_output_file);
				count_loop++;
			};
		};
	};
	number_of_jumps=count_loop;
	fseek(txd_output_file,temporary_file_pointer,SEEK_SET);
	
	/*
	e=0;
	temporary_file_pointer=ftell(txd_output_file);
	
	  while (1)
	  {
	  put_next_word_in_string(txd_output_file,global_huge_string);
	  if ((global_huge_string[0]=='~')&&(ishex(global_huge_string[1]))
	  {
	  addresses[count_loop]=hex2dec(global_huge_string,1);
	  count_loop++;
	  };
	  
		(ishex(global_huge_string[0])
		e=0;
		
	while (e*/
	
	if (((address_of_parsing_line%4)==0)&&(address_of_parsing_line!=0)) printf(".%lx",address_of_parsing_line);
	orflag=0;
	afterif=0;
	stack_pointer=0;
	count_loop=1;
	while (count_loop<=address_stack_pointer)
	{
		indent_spaces();
		fprintf(uninform_output_file,"};");
		fprintf(uninform_output_file,"\n");
		count_loop++;
	};
	address_stack_pointer=0;
	fprintf(uninform_output_file,"];\n");
	if ((strcmp("Main",global_small_string))==0)
	{
		fprintf(uninform_output_file,"\n![Main routine]");
		put_next_word_in_string(txd_output_file,global_small_string);
	};
	
	fprintf(uninform_output_file,"\n![");
	
	put_next_word_in_string(txd_output_file,global_small_string);
	global_small_string[strlen(global_small_string)-1]='\0';
	count_loop=0;
	while (count_loop<=screen_width)
	{
		fprintf(uninform_output_file,"_");
		count_loop++;
	};
	
	fprintf(uninform_output_file,"];\n\n[rn_%s ",global_small_string);
	put_next_word_in_string(txd_output_file,global_small_string);
	global_number=atoi(global_small_string);
	count_loop=0;
	while (count_loop<global_number)
	{
		fprintf(uninform_output_file,"local%d ",count_loop);
		count_loop++;
	};
	fprintf(uninform_output_file,";\n");
	indent_spaces();
};
//if (global_small_string[0]=='A') printf("Action Routine...\n");
};

fprintf(uninform_output_file,"];\n\n![Disinformation: lwtcdi:http://www2.prestel.co.uk/lwtcdi/all\n]");
fclose(txd_output_file);
fclose(infodump_output_file);
//fclose(imported_stuff);
};

void indent_spaces()
{
	int e;
	
	e=0;
	if ((dont_linefeed==0)&&(dontcrplease==0))
	{
		while (e<address_stack_pointer)
		{
			fprintf(uninform_output_file,indent_string);
			e++;
		};
	};
};

void printobject(char string[200],int howmany)
{
	long temporary;
	temporary=ftell(infodump_output_file);
	sprintf(string,"%d. Attributes:",howmany);
	temporary_file_pointer=find_string_in_file(0L,infodump_output_file,string,1);
	temporary=find_string_in_file(temporary_file_pointer,infodump_output_file,"Description: \"",1);
	fseek(infodump_output_file,temporary_file_pointer,SEEK_SET);
	string[0]='\0';
	copytext(infodump_output_file,string);
	underscore(string);
	fseek(infodump_output_file,temporary,SEEK_SET);
};

void printtext(FILE *stream)
{
	int c;
	while (1)
	{
		c=getc(stream);
		if (c=='"') break;
		fprintf(uninform_output_file,"%c",c);
	};
};

void printtextcr(FILE *stream)
{
	int c;
	
	while (1)
	{
		c=getc(stream);
		if (c==linefeed) break;
		if (c>=32) fprintf(uninform_output_file,"%c",c);
	};
};


void save_file_position (FILE *stream)
{
	stored_file_position=ftell(stream);
};

//a simple search routine... case sensitive:

//wherefrom	where to start looking in the file
//stream    which file to look in
//searchitbud	the string to search for
//searchtimes	how many times to search for it

//if it can find it, it returns the (long) fileposition *AFTER* the string
//if it can't find it 'searchtimes' number of times in the file from the place, it returns '-1'

long find_string_in_file(long wherefrom,FILE *stream,char searchitbud[100],int searchtimes)
{
	int searchness,c,counttimes;
	long tempstreampos;
	searchness=0;
	counttimes=0;
	tempstreampos=ftell(stream);
	fseek(stream,wherefrom,SEEK_SET);
	while ((c=getc(stream))!=EOF)
	{
		if (c==searchitbud[searchness])
		{
			if ((ftell(stream)>end_of_search)&&(end_of_search!=0))
			{
				fseek (stream,tempstreampos,SEEK_SET);
				return(-1);
			};
			
			searchness++;
			if (searchness==strlen(searchitbud))
			{
				counttimes++;
				if ((counttimes==searchtimes)||(searchtimes==0))
				{
					all_purpose_long=ftell(stream);
					fseek (stream,tempstreampos,SEEK_SET);
					return(all_purpose_long);
				}
				else searchness=0;
			};
		}
		else searchness=0;
	};
	return(-1);
};

void strbeg(char *stringin,char *whattoappend)
{
	char tempstring[1000];
	strcpy(tempstring,whattoappend);
	strcat(tempstring,stringin);
	strcpy(stringin,tempstring);
};

int testaddress()
{
	char string[100];
	put_next_word_in_string(txd_output_file,string);
	
	/*if((strcmp(moveplayerbracket,string))==0) strcpy(parsed_line_to_print,"PlayerTo (");
	else
	if((strcmp(ofclassbracket,string))==0)
	{
	reset_commonly_used_strings();
	parse_input_operand(0);
	strcat(parsed_line_to_print," ofclass (");
	if (parse_input_operand(1)==5)
	{
	global_small_string[0]='\0';
	sprintf(global_small_string,"%d. Attributes:",global_number);
	temporary_file_pointer=find_string_in_file(0L,infodump_output_file,global_small_string,1);
	temporary_file_pointer=find_string_in_file(temporary_file_pointer,infodump_output_file,"Description: \"",1);
	if (temporary_file_pointer!=-1)
	{
	fseek(infodump_output_file,temporary_file_pointer,SEEK_SET);
	copytext(infodump_output_file,global_small_string);
	underscore(global_small_string);
	strcat(parsed_line_to_print,global_small_string);
	};
	};
	strcat(parsed_line_to_print,")");
	
	  if (currently_parsed_opcode[6]=='s')
	  {
	  strcpy(stored_parsed_line,parsed_line_to_print);
	  parsed_line_to_print[0]='\0';
	  };
	  return(2);
	  }
	  else
	  if((strcmp(printthebracket,string))==0) strcpy(parsed_line_to_print,"print (the) ");
	  else
	  if ((strcmp(printthembracket,string))==0) strcpy(parsed_line_to_print,"print (itorthem) ");
	  else
	  if ((strcmp(printthebracketcaps,string))==0) strcpy(parsed_line_to_print,"print (The) ");
	  else
	  if ((strcmp(printnamebracket,string))==0) strcpy(parsed_line_to_print,"print (name) ");
	  else
	  if ((strcmp(printthenumber,string))==0) strcpy(parsed_line_to_print,"print (number) ");
	  else
	  
		if ((strcmp(verbbracket,string))==0)
		{
		put_next_word_in_string(txd_output_file,string);
		gimmename(start_of_verb_names,string);
		strcat(parsed_line_to_print,"<");
		strcat(parsed_line_to_print,string);
		strcat(parsed_line_to_print," ");
		if ((opcodebytes[1]==19)||(opcodebytes[1]==27)) parse_input_operand(0);
		else strcat(parsed_line_to_print," ");
		strcat(parsed_line_to_print,">;\n");
		return(2);
		}
		else
		{
	*/
	if ((strcmp("sp",string))==0)
	{
		string[0]='\0';
		pull_stack(string);
	};
	
	strbeg(parsed_line_to_print,"(");
	strbeg(parsed_line_to_print,string);
	strbeg(parsed_line_to_print,"rn_");
	
	return(0);
};

void underscore(char string[200])
{
	int count;
	count=0;
	while (count<strlen(string))
	{
		if ((string[count]>='A')&&(string[count]<='Z')) string[count]-=('Z'-'z');
		if (string[count]=='"') string[count]=' ';
		if (string[count]==',') string[count]='_';
		if (string[count]==' ') string[count]='_';
		if (string[count]==':') string[count]='_';
		if (string[count]=='.') string[count]='_';
		if (string[count]=='=') string[count]='_';
		if (string[count]==';') string[count]='_';
		if (string[count]=='(') string[count]='_';
		if (string[count]==')') string[count]='_';
		count++;
	};
};

int untilhexchar(FILE *stream)
{
	int success,isspace=0,c,d;
	
	success=0;
	
	while (success!=1)
	{
		c=getc(stream);
		if (c=='R') lastroutinefound=ftell(stream);
		if (c==',')
		{
			c=getc(stream);
			return(-2);
		};
		
		if (c==' ')
		{
			isspace=1;
			continue;
		};
		
		if (c=='X')
		{
			c=getc(stream);
			return(-1);
		};
		
		is_byte_hex(c);
		
		if (((is_byte_hex(c))&&(isspace==1)))
		{
			
			d=getc(stream);
			if (is_byte_hex(d))
			{
				save_file_position(stream);
				if (getc(stream)==' ')
				{
					load_file_position(stream);
					return(makehexbyte(c,d));
				};
			};
		};
		
		isspace=0;
	};
	return(-1);
};

main(int argc,char *argv[])
{
	int c,lf2cr;
	long searchpos,count;
	
	char defname[128];
	char outname[128];
	char objname[128];
	unsigned long hexaddr;
	int errflg;
	
	strcpy(defname,"zorkatts.txt");	// the default name for attributes
	strcpy(objname,"zinfoobj");		//default name for objects file
	
	errflg = 0;
	
	/* Parse the options */
	
	while ((c = getopt (argc, argv, "dboaheljpi:D:I:")) != EOF) {
		switch (c) {
			
		case 'd':
			option_decimal=1;
			break;
		case 'b':
			option_printhex=1;
			break;
		case 'j':
			option_alljumps=1;
			break;
		case 'h':
			option_highobjects=1;
			break;
		case 'l':
			option_lowobjects=1;
			break;
		case 'a':
			option_printaddress=1;
			break;
		case 'o':
			option_erase=1;
			break;
		case 'p':
			option_patch=1;
			break;
		case 'i':
			option_indent=atoi(optarg);
			break;
		case 'D':
			strcpy(defname,optarg);
			break;
		case 'I':
			strcpy(objname,optarg);
			break;
		case '?':
		default:
			errflg++;
		}
	}
	/* Display usage if unknown flag or no story file */
	
	if (errflg || optind >= argc) {
		printf("DisInforMation BETA version 3.8 (c)1997 by Jeremy A.Smith\n");
		printf(" Usage:\n");
		printf(" TXD >(filename) -adnw0 (name of .Z5 file)\n");
		printf(" Infodump >zinfoobj -odw0 (name of .Z5 file)\n");
		printf(" Uninform -switches (same at txd output filename) (output filename)\n");
		printf("Switches:");
		printf("	I<filename> - Infodump output filename (default zinfoobj)\n");
		printf("	D<filename> - Definitions file (default zorkatts.txt\n");
		printf("	d - everything in decimal (defaults to hex)\n");
		printf("	b - print Z-code hex bytes\n");
		printf("	i - spaces to indent (0 for no indent)\n");
		printf("	j - print all jumps and references\n");
		printf("	h - print all 4-digit hex numbers as object descriptions\n");
		printf("	l - print all 2-digit hex numbers as object descriptions\n");
		printf("	a - print Z-code addresses in decompilation as labels\n");
		printf("	o - overwrite output file if it exists\n");
		printf("	p - patch gamefile - uninform -p <to patch><patch out>xxxxxx xx xx\n");
		printf("	where xxxxxx is a 6-digit hex number, and xx is a 2-digit hex\n");
		printf("	patched file will be written to <patch out>\n");
		printf("Author can be contacted at jeremyasmith@lwtcdi.prestel.co.uk\n");
		printf("Failing that, jeremyalsmith@hotmail.com will work forever.\n");
		printf("\n");
		exit (EXIT_FAILURE);
	}
	//put indents in indent_string
	count_loop=0;
	while (count_loop<option_indent)
	{
		strcat(indent_string," ");
		count_loop++;
	};
	
	//the following is a gamefile patch function...
	
	if (option_patch)
	{
		if((uninform_output_file=fopen(argv[optind],"r+b"))==NULL)
		{
			printf("Sorry, can't find input file. Exiting...\n");
			exit(0);
		};
		optind++;
		if((imported_stuff=fopen(argv[optind],"w+b"))==NULL)
		{
			printf("Sorry, can't find the txd_output_fileut file. Exiting...\n");
			printf("For help, run DisInforMation with no parameters...\n");
			exit(0);
		};
		optind++;
		printf("Patching at ");
		//if (strlen(hexbarf)!=6) printf("Nope!! Sorry, 6 digits only. z to exit. Please re-type that.\n");
		hexaddr=makehexbyte(argv[optind][4],argv[optind][5]);
		hexaddr+=makehexbyte(argv[optind][2],argv[optind][3])*256L;
		hexaddr+=makehexbyte(argv[optind][0],argv[optind][1])*65536L;
		printf("%lx with ",hexaddr);
		optind++;
		count=0;
		while (ftell(uninform_output_file)!=hexaddr)
		{
			c=getc(uninform_output_file);
			putc(c,imported_stuff);
		};
		
		while (optind<argc)
		{
			fseek(uninform_output_file,hexaddr+count,SEEK_SET);
			
			if (option_decimal==0)
			{
				c=makehexbyte(argv[optind][0],argv[optind][1]);
			}
			else
				c=atoi(argv[optind]);
			putc(c,imported_stuff);
			if (optind==argc-1) printf(" and %d.",c);
			else printf("%d,",c);
			optind++;
			count++;
		};
		
		c=getc(uninform_output_file);
		while ((c=getc(uninform_output_file))!=EOF)
		{
			putc(c,imported_stuff);
		};
		fclose(imported_stuff);
		fclose(uninform_output_file);
		exit(0);
	};
	
	if((txd_output_file=fopen(argv[optind],"r+b"))==NULL)
	{
		printf("Sorry, can't find the input file. Exiting...\n");
		printf("For help, run DisInforMation with no parameters...\n");
		exit(0);
	};
	
	//if (argv[optind+1][0]=='\0')
	
	if (optind+1>=argc)
	{
		strcpy(outname,"zinfoout.txt");
	}
	else strcpy(outname,argv[optind+1]);
	
	
	if((attr_file=fopen(defname,"r+b"))==NULL)
	{
		no_attr_file=1;
	};
	
	if((uninform_output_file=fopen(outname,"r+b"))!=NULL)
	{
		printf("Hmm... A file already exists with the same name... \n");
		if (option_erase==1)
		{
			printf("Erasing over file, due to 'overwrite' switch.\n");
		}
		else
		{
			printf("Do you wish to write over it (Y to do so)\n");
			scanf("%s",global_small_string);
			if ((global_small_string[0]!='y')&&(global_small_string[0]!='Y'))
			{
				printf("Exiting... For help, run DisInforMation with no parameters...\n");
				fclose(uninform_output_file);
				exit(0);
			};
		};
	};
	
	if((uninform_output_file=fopen(outname,"w+b"))==NULL)
	{
		printf("Sorry, couldn't create the output file. Exiting...\n");
		printf("For help, run DisInforMation with no parameters...\n");
		exit(0);
	};
	
	if ((infodump_output_file=fopen(objname,"r+b"))==NULL)
	{
		printf("Sorry, can't find zinfoobj or specified Infodump file.\n");
		printf("'zinfoobj' is the output from Infodump.\n");
		printf("For help, run DisInforMation with no parameters...\n");
		exit(0);
	};
	
	printf("Output file:%s\n",outname);
	printf("Input file:%s\n",argv[optind]);
	printf("Definitions file:%s\n",defname);
	printf("Objects file:%s\n",objname);
	
	buildcrdefs();
	//let's work out linefeed=13 or 10 or whatever
	putdefault ();
	
	temporary_file_pointer=find_string_in_file(0L,txd_output_file,"high address = ",1);
	fseek(txd_output_file,temporary_file_pointer,SEEK_SET);
	put_next_word_in_string(txd_output_file,global_small_string);
	printf("\n!High Address:%s\n",global_small_string);
	fseek(txd_output_file,0L,SEEK_SET);
	startact=find_string_in_file(0L,infodump_output_file,"**** Verb action routines ****",1);
	if (find_string_in_file(0L,txd_output_file,"\" / Inform v\"",1)!=-1)
	{
		informdefined=1;
		printf("!Inform gamefile detected...\n");
	};
	
	if (find_string_in_file(0L,txd_output_file,"\"6/7\"",1)!=-1)
	{
		inform67_defined=1;
		printf("!Inform 6/7 gamefile detected...\n");
		printf("!Properties, attributes, verbnames etc auto-defined...\n");
	};
	
	/*temporary_file_pointer=find_string_in_file(0L,infodump_output_file,"Z-code version:",1);
	fseek(infodump_output_file,temporary_file_pointer,SEEK_SET);
	put_next_word_in_string(infodump_output_file,global_small_string);
	if ((strcmp("3",global_small_string)!=0))
	{
	inform67_defined=1;
	};
	fseek(infodump_output_file,0L,SEEK_SET);
	*/
	fseek(txd_output_file,0L,SEEK_SET);
	
	//printf("%lx",startact);
	
	count_loop=1;
	temporary_file_pointer=find_string_in_file(0L,infodump_output_file,"**** Objects ****",1);
	
	while (count_loop<=maximum_objects_in_game)
	{
		sprintf(global_small_string,"%d. Attr",count_loop);
		objectpos[count_loop]=find_string_in_file(temporary_file_pointer,infodump_output_file,global_small_string,1);
		temporary_file_pointer=objectpos[count_loop];
		count_loop++;
	};
	
	getserialnumber();
	parseeverything();
	printf ("\nFinished!!");
	return(1);
};

void putdefault()
{
/*
temporaryagain=find_string_in_file(0L,imported_stuff,"doprintnumber",1);
if (temporaryagain!=-1)
{
fseek(imported_stuff,temporaryagain,SEEK_SET);
if (temporaryagain!=-1)
{
fprintf(uninform_output_file,"![Print (number) found ");
backtrack(txd_output_file,printthenumber);
fprintf(uninform_output_file,", being at address %s]\n",printthenumber);
};
};
	*/
	//find out how many objects there are in zinfoobj
	temporary_file_pointer=find_string_in_file(0L,infodump_output_file,"Object count = ",1);
	fseek(infodump_output_file,temporary_file_pointer,SEEK_SET);
	put_next_word_in_string(infodump_output_file,global_small_string);
	maximum_objects_in_game=atoi(global_small_string);
	fprintf(uninform_output_file,"![Maximum Objects:%d]\n\n",maximum_objects_in_game);
	
	/*search for debug names (Inform 6/7 only)... we search in the sequence
	of 'last found, continue from there', as the messages come first, then the
	attribute names, then the property names, then the verb names, which are
	all part of the messages anyway. No point searching from the beginning of
	the file.*/
	
	start_of_messages=find_string_in_file(0L,txd_output_file,": S001 \"",0)-15;
	start_of_attribute_names=find_string_in_file(start_of_messages,txd_output_file," \"animate\"",0)-15;
	if (find_string_in_file(start_of_messages,txd_output_file," \"male\"",0)==-1) start_of_property_names=find_string_in_file(start_of_messages,txd_output_file,"before\"",0)-15;
	else start_of_property_names=find_string_in_file(start_of_messages,txd_output_file," \"male\"",0)-15;
	start_of_verb_names=find_string_in_file(start_of_property_names,txd_output_file,"\"Pronouns",0)-15;
	
	//let's start decompiling at the beginning of the code
	
	temporary_file_pointer=find_string_in_file(0L,txd_output_file,"[Start of code",1);
	fseek(txd_output_file,temporary_file_pointer,SEEK_SET);
};
