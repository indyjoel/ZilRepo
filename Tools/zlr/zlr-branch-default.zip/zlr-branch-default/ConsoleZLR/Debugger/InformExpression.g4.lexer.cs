﻿namespace ZLR.Interfaces.SystemConsole.Debugger
{
    partial class InformExpressionLexer
    {
    }
}
