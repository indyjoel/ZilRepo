=== What is ZLR? ===

ZLR is a .NET implementation of the [Z-machine](http://www.ifwiki.org/index.php/Z-machine).
Originally developed as a proof of concept for using JIT to speed up complex
interactive fiction games, ZLR continues to be developed for use as a debugger
and integration test engine in [ZILF](https://foss.heptapod.net/zilf/zilf).

This project's ongoing development is made possible by the hosting services
generously provided by [Octobus](https://octobus.net/) and
[Clever Cloud](https://www.clever-cloud.com>).